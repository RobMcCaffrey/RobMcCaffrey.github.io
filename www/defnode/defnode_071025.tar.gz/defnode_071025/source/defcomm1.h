c include commons for defnode

c set array dimensions in parameter statement below

c MAX_block max number of blocks (BL)
c MAX_corner max corners defining a single block
c MAX_f max number of faults (FA)
c MAX_gps max number of observed gps
c MAX_gpsfiles max number of gps files read in (GP)
c MAX_grids  max number of grids to calculate
c MAX_gridpts max number of grid points (GR)
c MAX_hc max number of hard constraints (HC)
c MAX_lines max number of profiles (PR)
c MAX_ll max number of line length changes (LL)
c MAX_moves max number of points to be moved (MV)
c MAX_nodes max number of nodes (set to MAX_x * MAX_z)
c MAX_num_fs max number of files containing points to calculate fault slip vectors (FS)
c MAX_p max number of free parameters
c MAX_poles max rotation poles (PO)
c MAX_prpts max total points in all profiles (PR)
c MAX_qfiles max number of earthquake files
c MAX_rm max lines of GPS sites removed (RM)
c MAX_rot max number of rotation rates
c MAX_sr max number of slip rates (SR)
c MAX_sr_files max number of slip rate files read in (SR)
c MAX_srce max number of transient sources
c MAX_ss max number of surface strain rates (SS)
c MAX_strain max number of uniform strain tensors (ST)
c MAX_sv max number of slip vectors (SV)
c MAX_sv_files max number of SV files read in (SV)
c MAX_tilt max number of tilt rates (TI)
c MAX_up max number of uplift rates (UP)
c MAX_up_files max number of uplift rate files
c MAX_x max x nodes per fault
c MAX_z max z nodes per fault

c* set dimensions here, careful of syntax
       PARAMETER (
     . MAX_block    = 90, 
     . MAX_corner   = 301, 
     . MAX_f        = 90,
     . MAX_gps      = 1000, 
     . MAX_gpsfiles = 29, 
     . MAX_gridpts  = 1000,
     . MAX_grids    = 5,
     . MAX_hc       = 20,
     . MAX_lines    = 20, 
     . MAX_ll       = 10,
     . MAX_moves    = 100,
     . MAX_nodes    = 350, 
     . MAX_num_fs   = 100,
     . MAX_p        = 450, 
     . MAX_poles    = 90,
     . MAX_prpts    = 350, 
     . MAX_qfiles   = 5,
     . MAX_rm       = 80,
     . MAX_rot      = 50,
     . MAX_srce     = 2,
     . MAX_sr       = 350, 
     . MAX_sr_files = 10,
     . MAX_ss       = 50, 
     . MAX_strain   = 90,
     . MAX_sv       = 300, 
     . MAX_sv_files = 10,
     . MAX_tilt     = 10, 
     . MAX_up       = 150, 
     . MAX_up_files = 5,
     . MAX_x        = 60, 
     . MAX_z        = 16 ) 

      character*3   gfdir
      character*4   expname
      character*5   expdir, defnode_version
      character*12  time_string
      character*23  longname
      character*80  infile, SUMline, parmfile
      character*256 aline2

      integer hc, hc_block, gf_code, fault_fit_type

      logical kcalculate, coseismic, vel_errors, getcovariance,
     .  triangles, write_der, write_cov, all_fault_0, all_fault_1, 
     .  node_decrease, wsimplex, read_votw, write_info, long_pos,
     .  mapinfo, gres, all_fault_fix, add_rand, gps_cov, do_dgt, htdp,
     .  write_hdr, chk_data, rand_seed
      logical  write_pens, parm_cov, wtable, get_stress, read_errors,
     .  keep_bad, use_gps, data_flag, get_phi_err, new_frame,
     .  use_crust2, use_prem, quakes, apply_penalty, write_all_fault,
     .  gamma5, fault_atr, write_input, donew, okada, check_equates,
     .  get_gps_parm, get_blk_parm, get_flt_parm, get_str_parm, invert
      logical no_srs, no_svs, no_ups, no_hcs, no_tilts, no_rot

c* special regions flags
      logical wusflag, sumaflag, pnwflag, wkbob, myflag
     
      common /flag1/ kcalculate, coseismic, vel_errors, getcovariance,
     .  triangles, write_der, write_cov, all_fault_0, all_fault_1, 
     .  node_decrease, wsimplex, read_votw, write_info, long_pos,
     .  mapinfo, gres, all_fault_fix, add_rand, gps_cov, do_dgt, htdp
      common /flag2/ write_pens, parm_cov, wtable, rand_seed,
     .  get_stress, keep_bad, use_gps, data_flag(5), get_phi_err, 
     .  new_frame, read_errors, write_hdr, chk_data,
     .  use_crust2, use_prem, quakes, apply_penalty, write_all_fault,
     .  gamma5, fault_atr, write_input, donew, okada, check_equates,
     .  get_gps_parm, get_blk_parm, get_flt_parm, get_str_parm, invert
      common /flag3/ wusflag, sumaflag, pnwflag, wkbob, myflag
      common /flag4/ no_srs, no_svs, no_ups, no_hcs, no_tilts, no_rot

      common /co1/ zero, one, two
      common /co4/ expname, expdir, gfdir, infile, SUMline, 
     .             defnode_version 
      common /co5/ nmoves, izero, ione, itwo, move_flag(MAX_moves)
      common /co6/ pmove(MAX_moves,4)

c* i/o
      common /io1/ k10, iparmread, ksum, ksumg, inline
      common /io2/ aline2, parmfile, longname, time_string

c* inversion controls
      logical ksim, grid_search, makeGF, makeGF_all, ksim_done, 
     .        adjust_pole
      common /sa1/ sa_controls(10), gs_controls(4),sa_min, sa_max
      common /sa2/ ksim, grid_search, makeGF, makeGF_all, ksim_done, 
     .             adjust_pole
      common /sa3/ psmin(14), psmax(14), penalty_factor(6)

c* SA stuff
      common /ambsa/ tt, idum

c* blocks=MAX_block, numcorners
      character*4 block_name, pole_out
      common /bl2/ block_centroid(MAX_block,2), block_area(MAX_block),
     .             v_block(MAX_block,2), spin(MAX_block),
     .             blockxy(MAX_corner,MAX_block,2),
     .             res_strain(MAX_block,10), bl_strain(MAX_block,6),
     .             block_res(MAX_block,3)
      common /bl3/ block_name(MAX_block), pole_out(MAX_block)
      common /bl4/ npole_block(MAX_block), nc_block(MAX_block), 
     .             nblocks, npole_out, nstrain_block(MAX_block)

c* poles max=MAX_poles
      common /po1/ poles(MAX_poles,9), fpole(9)
      common /po2/ npole_invert(MAX_poles), nblock_ref, num_pole_invert,
     .             num_poles

c* strain tensors
      common /str1/ strain(MAX_strain,9), strain_cen(MAX_strain,2)
      common /str2/ nstrain_invert(MAX_strain), num_strain_invert,
     .              num_strain

c* num gps=MAX_gps
      character*4 gps_fname, ref_site, gps_filename*30
      character*8 gps_name
      logical gps_invert, gps_keep, redo_site
      common /gps1/ num_gps, num_gps_used, num_gf_pts, npar_block,
     .              num_gf_run,
     .              nblock_gps(MAX_gps), kgps_file(MAX_gps),
     .              num_gps_file, loc_gps(MAX_gps),  
     .              num_file(MAX_gpsfiles), num_gps_poles,
     .              ngps_pole(MAX_gpsfiles)
      common /gps2/ gps_obs(MAX_gps,5), gps_def(MAX_gps,2), 
     .              gps_rot(MAX_gps,5), gps_net(MAX_gps,5),
     .              gps_str(MAX_gps,2), gps_pos(MAX_gps,2),
     .              gf_pos(MAX_gps,2), gf_pos_new(MAX_gps,2)
      common /gps3/ gps_name(MAX_gps), gps_filename(MAX_gpsfiles),
     .              gps_fname(MAX_gpsfiles), ref_site(MAX_gpsfiles)
      common /gps4/ gps_invert(MAX_gpsfiles), gps_keep(MAX_gps), 
     .              redo_site(MAX_gps)
      common /gps5/ gps_pole(MAX_gpsfiles,9), gps_wt(MAX_gpsfiles,4),
     .              ref_vel(MAX_gpsfiles,2)
      common /gps6/ gps_global_weight, gps_near, gps_too_far,
     .              dx_node_new


c* profiles, max=MAX_lines
      character*80 volcfile, quakefile
      integer prof_n, prof_num
      logical make_profile
      common /pr1/ u_lines(MAX_prpts,3,3), prof_dx(MAX_lines), 
     .             prof_az(MAX_lines), prof_width(MAX_lines), 
     .             prof_start(MAX_lines,2), prof_pos(MAX_prpts,2)
      common /pr2/ prof_n(MAX_lines), kfirst_point(MAX_lines), 
     .             nlines, prof_num(MAX_lines), num_quakefiles
      common /pr3/ make_profile
      common /pr4/ volcfile, quakefile(MAX_qfiles)
      
c* misc pts
      character*4  name_pt
      common /pt1/ ndef_pts
      common /pt2/ pdef_pt(500,2), u_pt(500,3)
      common /pt3/ name_pt(500)

c* grids
      logical make_grid, on_fault
      common /gr1/ u_grid(15, MAX_gridpts, MAX_grids), 
     .             pgrid(MAX_grids,6)
      common /gr2/ x0grid, dxgrid, y0grid, dygrid
      common /gr3/ nxgrid, nygrid, jblock_grid(MAX_gridpts, MAX_grids)
      common /gr4/ make_grid, on_fault(MAX_gridpts, MAX_grids)

c* slip vectors = MAX_sv
      character sv_label*25, sv_file*30
      common /sv1/ num_sv, num_svfile, kblk_sv(MAX_sv,2), 
     .             ksv_file(MAX_sv)
      common /sv2/ sv_obs(MAX_sv), sv_sig(MAX_sv),sv_pos(MAX_sv,2),
     .             sv_calc(MAX_sv), sv_lon(MAX_sv_files), 
     .             sv_lat(MAX_sv_files), sv_az(MAX_sv_files)
      common /sv3/ sv_label(MAX_sv), sv_file(MAX_sv_files)

c* num slip rates = MAX_sr
      character sr_label*40, sr_file*30
      common /sr1/ num_sr, num_srfile, kblk_sr(MAX_sr,2), 
     .             ksr_err(MAX_sr), ksr_file(MAX_sr)
      common /sr2/ sr_obs(MAX_sr,2), sr_sig(MAX_sr),
     .             sr_pos(MAX_sr,2), sr_calc(MAX_sr), sr_az(MAX_sr)
      common /sr3/ sr_label(MAX_sr), sr_file(MAX_sr_files)

c* uplifts = MAX_up
      character  up_name*8, up_file*30
      integer up_type, up_file_no
      common /up1/ num_up, num_up_file
      common /up2/ up_name(MAX_up), up_file(MAX_up_files)
      common /up3/ up_obs(MAX_up,2), up_sig(MAX_up), up_pos(MAX_up,2),
     .             up_calc(MAX_up), up_offset(MAX_up_files)
      common /up4/ up_type(MAX_up), up_file_no(MAX_up)

c* line length changes = MAX_ll
      character*4 name_ll
      common /ll1/ num_ll, num_ll_sites, num_site_ll(MAX_ll,2),
     .             ll_block(MAX_ll)
      common /ll2/ name_ll(MAX_ll)
      common /ll3/ pos_ll(MAX_ll,2), obs_ll(MAX_ll), sig_ll(MAX_ll),
     .             calc_ll(MAX_ll), vel_ll(MAX_ll,2), daz_ll(MAX_ll,2)

c* faults=MAX_f, x-nodes=MAX_x, z-nodes=MAX_z, MAX_nodes = MAX_x*MAX_z
      logical phi_free, f_makeGF, fault_flag, fprm_fixed
      logical node_hwblock, nodes_sigma, nodes_read, nodes_value

      character fault_name*10, dd_line*240 

      common /fa1/ nxf(MAX_f), nzf(MAX_f), khw_blk(MAX_x,MAX_z,MAX_f),
     .             kfw_blk(MAX_x,MAX_z,MAX_f), nfault, nz_fixd(10), 
     .             num_fixd, nfcnct(100,2), nfmerge(100,2), nfcncts, 
     .             nfmerges, fault_fit_type(MAX_f), 
     .             kgf_code(MAX_x,MAX_z,MAX_f),
     .             node_prof(MAX_f, MAX_x),
     .             gf_code(MAX_f,MAX_x,MAX_z,5)
      common /fa2/ slip_n(MAX_x,MAX_z,MAX_f,5), smooth(MAX_f,2),
     .             xynode(2,MAX_x,MAX_z,MAX_f), 
     .             xwnode(2,MAX_x,MAX_z,MAX_f), 
     .             znode(MAX_z,MAX_f), z_fixd(10),
     .             phi(MAX_x,MAX_z,MAX_f), phi_err(MAX_x,MAX_z,MAX_f),
     .             fault_sums(MAX_f,7), cff(MAX_x,MAX_z,MAX_f),
     .             depth_max(MAX_f), tmom_node(MAX_x,MAX_z,MAX_f),
     .             fault_dip(MAX_x,MAX_z,MAX_f), 
     .             fault_strike(MAX_x,MAX_z,MAX_f), 
     .             f_parm(MAX_f, MAX_x, 3), f_parm_err(MAX_f, MAX_x, 3),
     .             fault_dip_az(MAX_f, MAX_x)
      common /fa3/ X_interp, W_interp, GFx_interp, GFw_interp
      common /fa4/ kmode, nodes_eq, node_eq(30,6), node_eq_type(30),
     .             nphi(MAX_x,MAX_z,MAX_f), node_fix(MAX_f, MAX_nodes)
      common /fa5/ node_hwblock, nodes_sigma
      common /fa6/ nodes_read(MAX_f), nodes_value(MAX_f), 
     .             phi_free(MAX_x,MAX_z,MAX_f), f_makeGF(MAX_f),
     .             fault_flag(MAX_f,3), fprm_fixed(MAX_f,3)
      common /fa7/ fault_name(MAX_f), dd_line(MAX_f, MAX_z-1)
      common /fa8/ xmom_lat(MAX_f,50,2), xmom_lat_err(MAX_f,50), 
     .             xmax_mom(MAX_f,2)

c* for fault rotations
      common /fa9/  numfo, nfo(MAX_f)
      common /fa10/ ffo(MAX_f, 3)

c* for node time series, transient sources
      logical source_invert
      common /ts1/ transient(MAX_f, MAX_srce, 9)
      common /ts2/ source_invert(MAX_f, MAX_srce)
      common /ts3/ nsource_parm(MAX_f, MAX_srce, 9)

c* for the subsurface strain calculations at nodes
      common /fa11/ s_tensor(MAX_x,MAX_z,MAX_f,6)

c max tilts=MAX_tilt
      character*8 tilt_name
      common /tlt1/ num_tilts
      common /tlt2/ tilt_name(MAX_tilt)
      common /tlt3/ tilt_obs(MAX_tilt), tilt_sig(MAX_tilt), 
     .              tilt_pos(MAX_tilt,2,2), tilt_length(MAX_tilt), 
     .              tilt_calc(MAX_tilt) 

c max shear strain rates =MAX_ss
      character*4  ss_name
      integer ss_type, ss_block
      common /ss1/ ss_name(MAX_ss)
      common /ss2/ ss_pos(MAX_ss,4,2), ss_obs(MAX_ss,3),
     .             ss_sig(MAX_ss,3), ss_calc(MAX_ss,3), 
     .             ss_vel(MAX_ss,9,2) 
      common /ss3/ num_ss, ss_type(MAX_ss), ss_block(MAX_ss,9)


c* fault slip files
      integer fs_block
      common /fsp1/ num_fs
      common /fsp2/ fs_xy(MAX_num_fs,2), fs_block(MAX_num_fs,2)

c** rotations = MAX_rot
      character*40 rot_name
      common /rot1/ num_rot, num_rotfile, kblk_rot(MAX_rot), 
     .              krot_file(MAX_rot)
      common /rot2/ rot_obs(MAX_rot),   rot_sig(MAX_rot),
     .              rot_pos(MAX_rot,2), rot_calc(MAX_rot)
      common /rot3/ rot_name(MAX_rot)

c** max hard constraints = MAX_hc
      logical hc_flag
      common /hc1/ hc(MAX_hc), hc_block(MAX_hc,2), num_hc
      common /hc2/ hc_pos(MAX_hc,2), hc_val(MAX_hc,2), hc_pen(MAX_hc)
      common /hc3/ hc_flag(MAX_hc)

c** layered structure
c      common /lay1/ nlayers
c      common /lay2/ h(MAX_layers), vp(MAX_layers), vs(MAX_layers),
c     .              ro(MAX_layers)

c***** END of include



