c* defnode
c* global constants 

      parameter (  
c* PII
     .  pii  = 3.14159265358979d0,
     .  pii2 = 6.28318530717959d0,

c* degrees to radians
     .  d2r =  1.7453292519943d-2,

c* radians to degrees
     .  r2d =  5.7295779513082d1,

c* kilometers to degrees on Earth
     .  x2d =  8.9932200116306d-3,

c* degrees to kilometers on Earth
     .  d2x =  111.19487777534d0,

c* Earth radius in kilometers
     .  Erad = 6370.9972d0 )

c* elastic constants
      common /con1/ xmu, xlambda

c* end of constants

