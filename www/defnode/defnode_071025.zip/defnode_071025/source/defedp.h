*************************************************************** 
***
***
***  EDGRN/EDCMP routines below; layered structure
***
***
***  they have been modified to calculate and use only 
***   the displacements, no strains or tilts
*************************************************************** 

        subroutine edgsub(nr1, r1, r2, nzs, zs1, zs2,
     .     srate, outdir)
*
*  edgmain; modified to be subroutine by Rob McCaffrey 9/27/2006
*
c
c       First implemented in Potsdam, Feb, 1999
c       Last modified: Potsdam, Nov, 2001, by R. Wang
c
      implicit real*8 (a-h,o-z)
c
*     include 'edgglobal.h'

      include "defconst.h"
      include 'edc.h'
c
       data pi,pi2/3.14159265358979d0,6.28318530717959d0/
*       data zseps/1.0d-02/
       data zseps/1.0d-04/
c
        double precision r(nrmax)
        common /rprofile/ r,nr
c
        integer lp,nno(nzmax)
        double precision hp(nzmax)
        common /sublayer/ hp,lp,nno
c
c       zrec: receiver depth
c       lzrec: sublayer no of receiver
c
        integer lzrec
        double precision zrec
        common /rec1/ zrec
        common /rec2/ lzrec
c       
c       model parameter:
c       nlayer: number of homogeneous layers
c
      integer nlayers
      dimension h(MAX_layers), vp(MAX_layers), vs(MAX_layers),
     .          ro(MAX_layers), player(7)
      common /model/ h,ro,vp,vs,player,nlayers 
c
c       original model parameters
c
      dimension z1(MAX_layers),z2(MAX_layers),
     .   ro1(MAX_layers),ro2(MAX_layers)
      dimension vp1(MAX_layers),vp2(MAX_layers),
     .   vs1(MAX_layers),vs2(MAX_layers)
      common /model0/z1,z2,ro1,ro2,vp1,vp2,vs1,vs2,l0
c
c       source parameters
c
        integer ls,ms,ics
        integer kpower(6)
        double precision zs,r0
        double precision sfct(6)
        common /source/ zs,r0,sfct,ls,ms,ics,kpower
c
c        table of J_n(x), dJ_n(x)/dx and n*J_n(x)/x
c       all multiplied by sqrt(x)
c
       double precision bsdx,bsfct(0:nnbess1,3)
       common /bessels/ bsdx,bsfct
c
c
c       work space
c
      integer i,j,l,itty,ierr,izs,nzs,istype,len
   
      double precision r1,r2,dr,zs1,zs2,dzs,xlambda,xmu
      double precision srate,moment
      double precision resolut(3)
      double precision u(10,nrmax)

      character*80 reports(3)
      character*2 grnfile0(3)
      character*3 outdir
      character*80 inputfile
      character*30 grnfile(3), grnhd

       data grnfile0 / 'ss', 'ds', 'cl'/
c
c       read input file file
c
*       write(*,'(a,$)')' Please type the file name of input data: '
*        read(*,'(a)')inputfile
*        open(10,file=inputfile,status='old')
        print *,' doing layers'

c
c       source-observation grid parameters
c       ==================================
c

*       call getdata(10,dataline)
*      read(dataline,*)zrec

* by RM, only surface observations
      zrec = 1.0d-3
      lzrec = 1

      nr = nr1

*      call getdata(10,dataline)
*       read(dataline,*)nr,r1,r2

       if(nr.le.1)then
         stop ' Error in edgmain: number of distance samples < 2!'
       else if(nr.gt.nrmax)then
         stop ' Error in edgmain: no of distance samples > nrmax!'
       else
         dr=(r2-r1)/dble(nr-1)
         if(dr.le.0.d0)then
           stop ' Error in edgmain: wrong distance stepping!'
         endif
          do i=1,nr
           r(i)=r1+dr*dble(i-1)
         enddo
       endif

*   call getdata(10,dataline)
*       read(dataline,*)nzs,zs1,zs2

       if(nzs.le.1)then
         stop ' Error in edgmain: number of source depths < 2!'
       else if(nzs.gt.nzsmax)then
         stop ' Error in edgmain: no of source depths > nzsmax!'
       else
         dzs=(zs2-zs1)/dble(nzs-1)
         if(dzs.le.0.d0)then
           stop ' Error in edgmain: wrong source depth stepping!'
         endif
       endif

       r0=0.5d0*dmax1(dzs,dr)

       do izs=1,nzs
         zs=zs1+dble(izs-1)*dzs
         if(dabs(zrec-zs).gt.0.d0
     &      .and.dabs(zrec-zs).le.zseps*dzs)then
           zrec=zs
           print *,'warning: an insignificant depth difference ',
     &              'between source and observation ignored!'
         endif
       enddo
c
c       wavenumber integration parameters
c       =================================
c

*     call getdata(10,dataline)
*     read(dataline,*)srate

       if(srate.le.0.d0)srate=10.d0
       itty=1
c
c       output files
c       ============
c

*       call getdata(10,dataline)
*       read(dataline,*)outdir,(grnfile0(i),i=1,3)

c
       len=index(gfname,' ')-1
       grnhd = outdir(1:3)//'/'//gfname(1:len)//'.hdr'

       do i=1,3
         grnfile(i)=outdir(1:3)//'/'//gfname(1:len)//'.'//grnfile0(i)
         print *, grnfile(i)
       enddo
c
c       global model parameters
c       =======================
c
       do i=1,3
         resolut(i)=5.d-02
       enddo
c
c       multilayered model parameters
c       =============================
c

*       call getdata(10,dataline)
*       read(dataline,*)l
       l = nlayers
       do i=1,l
*         call getdata(10,dataline)
*         read(dataline,*)j,h(i),vp(i),vs(i),ro(i)
         if(vs(i).le.0.d0) vs(i)=1.0d-02*vp(i)
       enddo

c
c       end of inputs
c       =============
c

*       close(10)
******
**  write out a header file describing the layered structure and Green's functions
        open(11, file = grnhd)
        write(11,1001)nr,r1,r2,nzs,zs1,zs2,zrec,xlambda,xmu
        write(11, '(i5)') nlayers
        do i=1,nlayers
         tmu = ro(i)*vs(i)*vs(i)
         tlam = ro(i)*vp(i)*vp(i) - 2.0d0*tmu
         write(11, '(6e12.4)') h(i),vp(i),vs(i),ro(i), tmu, tlam
        enddo
        close(11)

c
c       determine upper und lower parameter values of each layer
c
       l0=1
       do i=2,l
         if(h(i).gt.h(i-1))then
           z1(l0)=h(i-1)
           vp1(l0)=vp(i-1)
           vs1(l0)=vs(i-1)
           ro1(l0)=ro(i-1)
c
           z2(l0)=h(i)
           vp2(l0)=vp(i)
           vs2(l0)=vs(i)
           ro2(l0)=ro(i)
           l0=l0+1
         else
           z1(l0)=h(i)
           vp1(l0)=vp(i)
           vs1(l0)=vs(i)
           ro1(l0)=ro(i)
         endif
       enddo
       if(z1(l0).eq.0.d0)then
           z1(l0)=h(l)
           vp1(l0)=vp(l)
           vs1(l0)=vs(l)
           ro1(l0)=ro(l)
       endif
c
c       construction of sublayers at the cutoff frequency
c
       write(*,*)'   '
       if(itty.eq.1)then
         write(*,*)'the multi-layered model used:'
       endif
       call edgsublay(resolut,itty,ierr)
       if(ierr.eq.1)then
         stop 'the layer index (MAX_layers) too small defined!'
       endif
c
        call edglayer(zs1,ls,zrec,lzrec,h,nlayers)
       xmu=ro(nno(lzrec))*vs(nno(lzrec))*vs(nno(lzrec))
       xlambda=ro(nno(lzrec))*vp(nno(lzrec))*vp(nno(lzrec))-2.d0*xmu
       reports(1)='Source type: strike-slip'
       reports(2)='Source type: dip-slip'
       reports(3)='Source type: compensated linear vector dipole'
       len=index(inputfile,' ')-1
c
       do istype=1,3
c
c         open output file
c
         kunit=20+istype
         write(*,'(a45)')reports(istype)
         open(kunit,file=grnfile(istype),status='unknown')
         write(kunit,'(a)')'# Green functions calculated with '
     &                     //'the program edgrn'
         write(kunit,'(a)')'# The input data file is '
     &                    //inputfile(1:len)
         write(kunit,'(a,a45,a)')'# ',reports(istype),
     &                    '   Dislocation: 1 meter'

         write(kunit,'(a)')'# Structure'
         write(kunit,'(a,i5)') '#', nlayers
        do i=1,nlayers
         write(kunit, '(a,4e12.4)') '#',h(i),vp(i),vs(i),ro(i)
        enddo

         write(kunit,'(a)')'#'
         write(kunit,'(a)')'# The 1. data line includes the parameters:'
         write(kunit,'(a)')'#'
         write(kunit,'(a,$)')'# nr, r1[m], r2[m]; '
         write(kunit,'(a,$)')'nzs, zs1[m], zs2[m]; obs.depth[m];'
         write(kunit,'(a)')' lambda[Pa], mu[Pa] (at obs. depth)'
         write(kunit,'(a)')'#'
         write(kunit,'(a)')'# The following data lines are'
         write(kunit,'(a)')'#'
         if(istype.le.2)then
           write(kunit,'(a)')'#   uz[m]         ur[m]         ut[m] '
     &        //'        ezz           err           ett   '
     &        //'        ezr           ert           etz   '
     &        //'        duz/dr'
         else
           write(kunit,'(a)')'#   uz[cm]        ur[cm]'
     &        //'        ezz           err           ett   '
     &        //'        ezr           duz/dr'
         endif
         write(kunit,'(a)')'#'
         write(kunit,1001)nr,r1,r2,nzs,zs1,zs2,zrec,xlambda,xmu
c
c         calculate Bessel function tables
c
         call edgbstab(3-istype)
c
         do izs=1,nzs
           zs=zs1+dble(izs-1)*dzs
           call edglayer(zs,ls,zrec,lzrec,h,nlayers)
            moment=ro(nno(ls))*vs(nno(ls))*vs(nno(ls))
           call edgmoment(istype,moment,ro(nno(ls)),
     &                     vp(nno(ls)),vs(nno(ls)))
c
           call edgwvint(u,r,nr,srate,xlambda,xmu,itty)

          if(istype.le.2)then
             do j=1,nr
*!*            write(kunit,'(10E14.6)')(u(i,j),i=1,10)
               write(kunit,'(3E14.6)')(u(i,j),i=1,3)
             enddo
           else
           do j=1,nr
*!*         write(kunit,'(10E14.6)')(u(i,j),i=1,2),(u(i,j),i=4,7),u(10,j)
            write(kunit,'(2E14.6)')(u(i,j),i=1,2)
           enddo
          endif
         enddo
         close(kunit)
       enddo
       print *,'#        Successful computations with EDGRN          #'
1001    format(2(i4,2E13.5),4E13.5)
 500    return
        end

***********************************************************************

      subroutine edgsublay(resolut,itty,ierr)
      implicit real*8 (a-h,o-z)
*      implicit none
c
c      First implemented in Potsdam, Feb, 1999
c      Last modified: Potsdam, Nov, 2001, by R. Wang
c
      integer itty,ierr
      double precision resolut(3)
c
*      include 'edgglobal.h'
      include 'edc.h'
c       
c       model parameter:
c       nlayers: number of homogeneous layers
c
        integer nlayers
       dimension h(MAX_layers), vp(MAX_layers), vs(MAX_layers),
     .           ro(MAX_layers), player(7)
       common /model/ h,ro,vp,vs,player,nlayers 
c
c      original model parameters
c
      dimension z1(MAX_layers),z2(MAX_layers),
     .   ro1(MAX_layers),ro2(MAX_layers)
      dimension vp1(MAX_layers),vp2(MAX_layers),
     .   vs1(MAX_layers),vs2(MAX_layers)
      common /model0/z1,z2,ro1,ro2,vp1,vp2,vs1,vs2,l0
c
c      work space
c
      double precision eps
      data eps/1.0d-02/
      integer i,i0,l
      double precision dh,dro,dvp,dvs,z,dz
c
      nlayers=0
      do l=1,l0-1
        dz=z2(l)-z1(l)
        dvp=2.d0*dabs(vp2(l)-vp1(l))/(vp2(l)+vp1(l))
        dvs=2.d0*dabs(vs2(l)-vs1(l))/(vs2(l)+vs1(l))
        dro=2.d0*dabs(ro2(l)-ro1(l))/(ro2(l)+ro1(l))
        i0=idnint(dmax1(dro/resolut(1),
     &       dvp/resolut(2),dvs/resolut(3)))
        i0=max0(1,i0)
        dro=(ro2(l)-ro1(l))/dz
        dvp=(vp2(l)-vp1(l))/dz
        dvs=(vs2(l)-vs1(l))/dz
        dh=dz/dble(i0)
        do i=1,i0
          nlayers=nlayers+1
          if(nlayers.ge.MAX_layers)then
            ierr=1
            return
          endif
          h(nlayers)=dh
          z=(dble(i)-0.5d0)*dh
          ro(nlayers)=ro1(l)+dro*z
          vp(nlayers)=vp1(l)+dvp*z
          vs(nlayers)=vs1(l)+dvs*z
        enddo
      enddo
c
c      last layer is halfspace
c
      nlayers=nlayers+1
      h(nlayers)=0.d0
      ro(nlayers)=ro1(l0)
      vp(nlayers)=vp1(l0)
      vs(nlayers)=vs1(l0)
c
      if(itty.eq.1)then
        write(*,'(7a)')' no ',' thick(m)  ','   vp(m/s) ',
     &    '  vs(m/s)  ',' ro(kg/m^3)'
        do i=1,nlayers
          write(*,1001)i,h(i),vp(i),vs(i),ro(i)
        enddo
      endif
1001      format(i4,4f11.4)
      ierr=0
      return
      end
***********************************************************************
c*******************************************************************************
c*******************************************************************************
        subroutine axb(a,b,n,l,m,c)
      implicit real*8 (a-h,o-z)
*        implicit none
c
c      First implemented in Potsdam, Feb, 1999
c      Last modified: Potsdam, Nov, 2001, by R. Wang
c
c
c       calculate c=a*b
c
        integer n,l,m
        double precision a(n,l),b(l,m),c(n,m)
c
        integer i,j,k
c
        do j=1,m
          do i=1,n
            c(i,j)=0.d0
            do k=1,l
              c(i,j)=c(i,j)+a(i,k)*b(k,j)
            enddo
          enddo
        enddo
        return
        end
***********************************************************************
c*******************************************************************************
c*******************************************************************************
      double precision function bessj0(x)
      implicit real*8 (a-h,o-z)
*      implicit none
c
c      First implemented in Potsdam, Feb, 1999
c      Last modified: Potsdam, Nov, 2001, by R. Wang
c
      double precision pi,pi2
      data pi,pi2/3.14159265358979d0,6.28318530717959d0/
c
c      J_0(x)
c
      double precision x,ax,x1,x2,theta,fct
      double precision a0,a1,a2,a3,a4,a5,a6
      double precision b0,b1,b2,b3,b4,b5,b6
      double precision c0,c1,c2,c3,c4,c5,c6
c
      data a0,a1,a2,a3,a4,a5,a6/1.00000000d0,
     + -2.24999970d0, 1.26562080d0,-0.31638660d0,
     +  0.04444790d0,-0.00394440d0, 0.00021000d0/
      data b0,b1,b2,b3,b4,b5,b6/0.79788456d0,
     + -0.00000077d0,-0.00552740d0,-0.00009512d0,
     +  0.00137237d0,-0.00072805d0, 0.00014476d0/
      data c0,c1,c2,c3,c4,c5,c6/-0.78539816d0,
     + -0.04166397d0,-0.00003954d0, 0.00262573d0,
     + -0.00054125d0,-0.00029333d0, 0.00013558d0/
c
      ax=dabs(x)
      if(ax.le.3.d0)then
        x2=(ax/3.d0)**2
        bessj0=a0+x2*(a1+x2*(a2+x2*(a3+x2*(a4+x2*(a5+x2*a6)))))
      else
        x1=3.d0/ax
        fct=b0+x1*(b1+x1*(b2+x1*(b3+x1*(b4+x1*(b5+x1*b6)))))
        theta=ax+c0+x1*(c1+x1*(c2+x1*(c3+x1*(c4+x1*(c5+x1*c6)))))
        theta=dmod(theta,2.d0*pi)
        bessj0=fct*dcos(theta)/dsqrt(ax)
      endif
c
      return
      end
***********************************************************************
c*******************************************************************************
c*******************************************************************************
      double precision function bessj(m,x)
      implicit real*8 (a-h,o-z)
*      implicit none
c
c      First implemented in Potsdam, Feb, 1999
c      Last modified: Potsdam, Nov, 2001, by R. Wang
c
      integer m
      double precision x
c
c      J_n(x), n <= 3
c
      double precision eps
      data eps/1.0d-10/
      integer i,m0
      double precision ax,bx,y0,y1,y,sum
c
      double precision bessj0,bessj1
c
      m0=iabs(m)
      ax=dabs(x)
      if(m0.eq.0)then
        bessj=bessj0(ax)
      else if(m0.eq.1)then
        bessj=bessj1(ax)
      else
        if(ax.gt.dble(m0))then
          bx=2.d0/ax
          y0=bessj0(ax)
          y1=bessj1(ax)
          do i=1,m0-1
            y=dble(i)*bx*y1-y0
            y0=y1
            y1=y
          enddo
          bessj=y
        else if(ax.eq.0.d0)then
          bessj=0.d0
        else
          y=1.d0
          bx=0.5d0*ax
          do i=1,m0
            y=y*bx/dble(i)
          enddo
          sum=y
          bx=bx*bx
          i=0
100          i=i+1
          y=-y*bx/dble(i)/dble(m0+i)
          sum=sum+y
          if(dabs(y).gt.eps*dabs(sum).or.i.lt.10)goto 100
          bessj=sum
        endif
      endif
      if(dble(m)*x.lt.0.d0.and.mod(m0,2).eq.1)bessj=-bessj
      return
      end
c*******************************************************************************
c*******************************************************************************
      double precision function bessj1(x)
      implicit real*8 (a-h,o-z)
*      implicit none
c
c      First implemented in Potsdam, Feb, 1999
c      Last modified: Potsdam, Nov, 2001, by R. Wang
c
      double precision pi,pi2
      data pi,pi2/3.14159265358979d0,6.28318530717959d0/
c
c      J_1(x)
c
      double precision x,ax,x1,x2,theta,fct
      double precision a0,a1,a2,a3,a4,a5,a6
      double precision b0,b1,b2,b3,b4,b5,b6
      double precision c0,c1,c2,c3,c4,c5,c6
c
      data a0,a1,a2,a3,a4,a5,a6/  0.50000000d0,
     + -0.56249985d0, 0.21093573d0,-0.03954289d0,
     +  0.00443319d0,-0.00031761d0, 0.00001109d0/
      data b0,b1,b2,b3,b4,b5,b6/  0.79788456d0,
     +  0.00000156d0, 0.01659667d0, 0.00017105d0,
     + -0.00249511d0, 0.00113653d0,-0.00020033d0/
      data c0,c1,c2,c3,c4,c5,c6/ -2.35619449d0,
     +  0.12499612d0, 0.00005650d0,-0.00637879d0,
     +  0.00074348d0, 0.00079824d0,-0.00029166d0/
c
      ax=dabs(x)
      if(ax.le.3.d0)then
        x2=(ax/3.d0)**2
        bessj1=x*(a0+x2*(a1+x2*(a2+x2*(a3+x2*(a4+x2*(a5+x2*a6))))))
      else
        x1=3.d0/ax
        fct=b0+x1*(b1+x1*(b2+x1*(b3+x1*(b4+x1*(b5+x1*b6)))))
        theta=ax+c0+x1*(c1+x1*(c2+x1*(c3+x1*(c4+x1*(c5+x1*c6)))))
        theta=dmod(theta,2.d0*pi)
        bessj1=dsign(1.d0,x)*fct*dcos(theta)/dsqrt(ax)
      endif
c
      return
      end
c*******************************************************************************
c*******************************************************************************
        subroutine memcpy(a,b,n)
      implicit real*8 (a-h,o-z)
*        implicit none
c
c       copy real array a to b
c
        integer n
        double precision a(n),b(n)
c
        integer i
c
        do i=1,n
          b(i)=a(i)
        enddo
        return
        end
***********************************************************************

      subroutine edgbstab(n)
      implicit real*8 (a-h,o-z)
*      implicit none
c
c      First implemented in Potsdam, Feb, 1999
c      Last modified: Potsdam, Nov, 2001, by R. Wang
c
      integer n
c
*      include 'edgglobal.h'
      include 'edc.h'
c
c
c       table of J_n(x), dJ_n(x)/dx and n*J_n(x)/x
c      all multiplied by sqrt(x)
c
      double precision bsdx,bsfct(0:nnbess1,3)
      common /bessels/ bsdx,bsfct
c
      double precision pi,pi2
      data pi,pi2/3.14159265358979d0,6.28318530717959d0/
      integer i,j
      double precision x,xsqrt,a,b
      double precision bessj0,bessj1,bessj
c
      do j=1,3
        bsfct(0,j)=0.d0
      enddo
      bsdx=pi2/dble(ndbess)
      if(n.eq.0)then
        do i=1,nnbess1
          x=bsdx*dble(i)
          xsqrt=dsqrt(x)
          bsfct(i,1)=xsqrt*bessj0(x)
          bsfct(i,2)=-xsqrt*bessj1(x)
          bsfct(i,3)=0.d0
        enddo
      else if(n.eq.1)then
        do i=1,nnbess1
          x=bsdx*dble(i)
          xsqrt=dsqrt(x)
          bsfct(i,1)=xsqrt*bessj1(x)
          a=xsqrt*bessj0(x)
          b=xsqrt*bessj(2,x)
          bsfct(i,2)=0.5d0*(a-b)
          bsfct(i,3)=0.5d0*(a+b)
        enddo
      else if(n.eq.2)then
        do i=1,nnbess1
          x=bsdx*dble(i)
          xsqrt=dsqrt(x)
          bsfct(i,1)=xsqrt*bessj(2,x)
          a=xsqrt*bessj1(x)
          b=xsqrt*bessj(3,x)
          bsfct(i,2)=0.5d0*(a-b)
          bsfct(i,3)=0.5d0*(a+b)
        enddo
      else
        stop ' Error in edgbstab: check 0<= n <= 2?'
      endif
c
      return
      end
c*******************************************************************************
c*******************************************************************************
        subroutine edghask(hk,m,k,z,n)
      implicit real*8 (a-h,o-z)
*        implicit none
c
c      First implemented in Potsdam, Feb, 1999
c      Last modified: Potsdam, Nov, 2001, by R. Wang
c
        integer m,n
        double precision k,z
        double precision hk(m,m)
c
*      include 'edgglobal.h'
      include 'edc.h'
c
c
c       nlayers: number of model layer
c
        integer nlayers
      dimension h(MAX_layers), vp(MAX_layers), vs(MAX_layers),
     .          ro(MAX_layers), player(7)
      common /model/ h,ro,vp,vs,player,nlayers 

c
      double precision eps0
      data eps0/1.0d-03/
c
      double precision k2,x,x2,xla,xmu
        double precision ex,ch,sh,eta
c
        k2=k*k
      x=k*z
      x2=x*x
      xmu=ro(n)*vs(n)**2
      xla=ro(n)*vp(n)**2-2.d0*xmu
      ex=dexp(x)
c
c      ch=(e^x+1/e^x)/2
c      sh=(e^x-1/e^x)/2x
c
      ch=0.5d0*(ex+1.d0/ex)
      if(dabs(x).le.eps0)then
        sh=1.d0+x2/6.d0*(1.d0+x2/20.d0)
      else
        sh=0.5d0*(ex-1.d0/ex)/x
      endif
c
      if(m.eq.2)then
c
c        propagator matrix for SH waves
c
        hk(1,1)=ch
        hk(1,2)=z*sh/xmu
        hk(2,1)=k*x*sh*xmu
        hk(2,2)=ch
      else if(m.eq.4)then
c
c        propagatior matrix for P-SV waves.
c
        eta=xmu/(xla+xmu)
        hk(1,1)=ch-x2*sh/(1.d0+eta)
        hk(1,2)=0.5d0*z*(-ch+(1.d0+2.d0*eta)*sh)/(1.d0+eta)/xmu
        hk(1,3)=x*(ch-eta*sh)/(1.d0+eta)
        hk(1,4)=x2*sh/(1.d0+eta)
        hk(2,1)=2.d0*xmu*k*x*(-ch+sh)/(1.d0+eta)
        hk(2,2)=hk(1,1)
        hk(2,3)=2.d0*xmu*k*hk(1,4)
        hk(2,4)=x*(ch+eta*sh)/(1.d0+eta)
        hk(3,1)=-hk(2,4)
        hk(3,2)=-0.5d0*x*z*sh/(1.d0+eta)/xmu
        hk(3,3)=ch+x2*sh/(1.d0+eta)
        hk(3,4)=0.5d0*z*(ch+(1.d0+2.d0*eta)*sh)/(1.d0+eta)/xmu
        hk(4,1)=-hk(2,3)
        hk(4,2)=-hk(1,3)
        hk(4,3)=2.d0*xmu*k*x*(ch+sh)/(1.d0+eta)
        hk(4,4)=hk(3,3)
      else
        stop ' Error in haskell: m schould be 2 or 4!'
      endif
c
      return
      end
c*******************************************************************************
c*******************************************************************************
        subroutine edgkern(y,k,ps,sh,eps)
      implicit real*8 (a-h,o-z)
*        implicit none
c
c      First implemented in Potsdam, Feb, 1999
c      Last modified: Potsdam, Nov, 2001, by R. Wang
c
c      calculation of response function in frequency-wavelength domain
c       y(6): solution vector
c       k: wave number
c       eps: relative accuracy
c
        double precision k,eps
        double precision y(6)
      logical ps,sh
c
*      include 'edgglobal.h'
      include 'edc.h'
c
c       
c       model parameter:
c       nlayers: number of model layers
c
        integer nlayers
      dimension h(MAX_layers), vp(MAX_layers), vs(MAX_layers),
     .          ro(MAX_layers), player(7)
      common /model/ h,ro,vp,vs,player,nlayers 
c
      integer i
c
      do i=1,6
        y(i)=0.d0
      enddo
c
      if(ps)call edgpsv(y,k,eps)
      if(sh)call edgsh(y,k,eps)
      return
      end        
***********************************************************************
      subroutine edglayer(zs,ls,zrec,lzrec,h,nlayers)
      implicit real*8 (a-h,o-z)
*        implicit none
c
c      First implemented in Potsdam, Feb, 1999
c      Last modified: Potsdam, Nov, 2001, by R. Wang
c
        integer ls,lzrec,nlayers
        double precision zs,zrec,h(nlayers)
c
*      include 'edgglobal.h'
      include 'edc.h'
cc
        integer lp,nno(nzmax)
        double precision hp(nzmax)
        common /sublayer/ hp,lp,nno
c
        integer l,n,li,lp0
        double precision z1
        double precision z(nzmax),z0(nzmax)
c
        lp0=1
        z0(lp0)=0.d0
        do n=1,nlayers-1
          lp0=lp0+1
          z0(lp0)=z0(lp0-1)+h(n)
        enddo
        lp0=lp0+1
        z0(lp0)=zrec
        lp0=lp0+1
        z0(lp0)=zs
c
c       sort the z0-profile
c
        do l=1,lp0-1
          do li=l+1,lp0
            if(z0(li).lt.z0(l))then
              z1=z0(l)
              z0(l)=z0(li)
              z0(li)=z1
            endif
          enddo
        enddo
c
c       delete duplicates
c
        lp=1
        z(lp)=0.d0
        do l=2,lp0
          if(z0(l).gt.z(lp))then
            hp(lp)=z0(l)-z(lp)
            lp=lp+1
            z(lp)=z0(l)
          endif
        enddo
        hp(lp)=0.d0
c
c       determine ls,lzrec
c
        do l=1,lp
          if(z(l).eq.zs)ls=l
          if(z(l).eq.zrec)lzrec=l
        enddo
c
c       determine layer no of each depth
c
        li=1
        z1=h(1)
        nno(1)=1
        do l=2,lp
          if(z(l).ge.z1.and.li.lt.nlayers)then
            li=li+1
            z1=z1+h(li)
          endif
          nno(l)=li
        enddo
c
        return
        end
***********************************************************************
        subroutine edgmatinv(a,m,k,z,n)
      implicit real*8 (a-h,o-z)
*        implicit none
c
c      First implemented in Potsdam, Feb, 1999
c      Last modified: Potsdam, Nov, 2001, by R. Wang
c
        integer m,n
        double precision k,z
        double precision a(m,m)
c
*      include 'edgglobal.h'
      include 'edc.h'
cc
c       model parameter:
c       nlayers: number of model layers
c
        integer nlayers
      dimension h(MAX_layers), vp(MAX_layers), vs(MAX_layers),
     .          ro(MAX_layers), player(7)
      common /model/ h,ro,vp,vs,player,nlayers 
c
        integer i,j
        double precision x,la,mu,eta,alfa,psi
c
        if(m.ne.4)then
          stop ' Error in edgmatinv: n != 4'
        endif
        x=k*z
      mu=ro(n)*vs(n)**2
      la=ro(n)*vp(n)**2-2.d0*mu
        eta=mu/(la+mu)
        alfa=2.d0*mu*k
        psi=1.d0+eta
        a(1,1)=x-eta
        a(1,2)=x/alfa
        a(1,3)=-x+psi
        a(1,4)=(psi+eta-x)/alfa
        a(2,1)=x+eta
        a(2,2)=-x/alfa
        a(2,3)=x+psi
        a(2,4)=-(psi+eta+x)/alfa
        a(3,1)=1.d0
        a(3,2)=1.d0/alfa
        a(3,3)=-1.d0
        a(3,4)=-1.d0/alfa
        a(4,1)=1.d0
        a(4,2)=-1.d0/alfa
        a(4,3)=1.d0
        a(4,4)=-1.d0/alfa
        do i=1,4
          do j=1,4
            a(i,j)=0.5d0*a(i,j)/psi
          enddo
        enddo
c
        return
        end
***********************************************************************
        subroutine edgmatrix(a,m,k,z,n)
      implicit real*8 (a-h,o-z)
*        implicit none
c
c      First implemented in Potsdam, Feb, 1999
c      Last modified: Potsdam, Nov, 2001, by R. Wang
c
        integer m,n
        double precision k,z
        double precision a(m,m)
c
*      include 'edgglobal.h'
      include 'edc.h'
cc       
c       model parameter:
c       nlayers: number of model layers
c
        integer nlayers
      dimension h(MAX_layers), vp(MAX_layers), vs(MAX_layers),
     .          ro(MAX_layers), player(7)
      common /model/ h,ro,vp,vs,player,nlayers 
c
        double precision x,la,mu,eta,alfa
c
        if(m.ne.4)then
          stop ' Error in edgmatrix: n != 4'
        endif
        x=k*z
      mu=ro(n)*vs(n)**2
      la=ro(n)*vp(n)**2-2.d0*mu
        eta=mu/(la+mu)
      alfa=2.d0*mu*k
        a(1,1)=1.d0
        a(1,2)=-1.d0
        a(1,3)=-x+1.d0+2.d0*eta
        a(1,4)=x+1.d0+2.d0*eta
        a(2,1)=alfa
        a(2,2)=alfa
        a(2,3)=alfa*(-x+1.d0+eta)
        a(2,4)=-alfa*(x+1.d0+eta)
        a(3,1)=1.d0
        a(3,2)=1.d0
        a(3,3)=-x
        a(3,4)=-x
        a(4,1)=alfa
        a(4,2)=-alfa
        a(4,3)=alfa*(-x+eta)
        a(4,4)=alfa*(x+eta)
c
        return
        end
***********************************************************************
      subroutine edgmoment(istype,strength,ro,vp,vs)
      implicit real*8 (a-h,o-z)
*      implicit none
c
c      First implemented in Potsdam, Feb, 1999
c      Last modified: Potsdam, Nov, 2001, by R. Wang
c
      double precision pi,pi2
      data pi,pi2/3.14159265358979d0,6.28318530717959d0/
c
      integer istype
      double precision ro,vp,vs
      double precision strength
c
c       source parameters
c
        integer ls,ms,ics
        integer kpower(6)
        double precision zs,r0
        double precision sfct(6)
        common /source/ zs,r0,sfct,ls,ms,ics,kpower
c
      integer i
c
      do i=1,6
        sfct(i)=0.d0
        kpower(i)=0
      enddo
c
      if(istype.eq.0)then
c
c        explosion source (m11=m22=m33=M0)
c
        ms=0
        ics=1
        sfct(1)=-strength/(2.d0*pi*ro*vp*vp)
        sfct(4)=-strength*(vs/vp)**2/pi
        kpower(4)=1
      else if(istype.eq.1)then
c
c        strike-slip (m12=m21=M0)
c
        ms=2
        ics=-1
        sfct(4)=strength/(2.d0*pi)
        sfct(6)=-sfct(4)
        kpower(4)=1
        kpower(6)=1
      else if(istype.eq.2)then
c
c        dip-slip (m13=m31=M0)
c
        ms=1
        ics=1
        sfct(3)=-strength/(2.d0*pi*ro*vs*vs)
        sfct(5)=sfct(3)
      else if(istype.eq.3)then
c
c        compensated linear vector dipole (CLVD) (m11=m22=-M0/2, M33=M0)
c
        ms=0
        ics=1
        sfct(1)=-strength/(2.d0*pi*ro*vp*vp)
        sfct(4)=strength*(3.d0-4.d0*(vs/vp)**2)/(4.d0*pi)
        kpower(4)=1
      else if(istype.eq.4)then
c
c        vertical-single-force (fz=F0)
c
        ms=0
        ics=1
        sfct(2)=strength/(2.d0*pi)
      else if(istype.eq.5)then
c
c        horizontal-single-force (fx=F0)
c
        ms=1
        ics=1
        sfct(4)=strength/(2.d0*pi)
        sfct(6)=sfct(4)
      else if(istype.eq.6)then
c
c        airgun in small pool (m11=m22=M0, fz=M0/r_source)
c
        ms=0
        ics=1
        sfct(2)=-strength/(2.d0*pi*r0)
        sfct(4)=-strength/(2.d0*pi)
        kpower(4)=1
      else
        stop ' Error in edgmoment: wrong source type switch no!'
      endif
c
      return
      end


        
***********************************************************************
        subroutine edgpsv(y,k,eps)
      implicit real*8 (a-h,o-z)
*        implicit none
c
c      First implemented in Potsdam, Feb, 1999
c      Last modified: Potsdam, Nov, 2001, by R. Wang
c
c      calculation of response to p-sv source
c       y(6): solution vector
c       k: wave number
c       eps: relative accuracy
c
*      include 'edgglobal.h'
      include 'edc.h'
cc
        double precision k,eps
        double precision y(6)
c
        integer lp,nno(nzmax)
        double precision hp(nzmax)
        common /sublayer/ hp,lp,nno
c
c       zrec: receiver depth
c       lzrec: sublayer no of receiver
c
        integer lzrec
        double precision zrec
        common /rec1/ zrec
        common /rec2/ lzrec
c       
c       model parameter:
c       nlayers: number of model layers
c
        integer nlayers
      dimension h(MAX_layers), vp(MAX_layers), vs(MAX_layers),
     .          ro(MAX_layers), player(7)
      common /model/ h,ro,vp,vs,player,nlayers 
c
c       source parameters
c
        integer ls,ms,ics
        integer kpower(6)
        double precision zs,r0
        double precision sfct(6)
        common /source/ zs,r0,sfct,ls,ms,ics,kpower
c
c       work space
c
        double precision eps0
        data eps0/1.0d-03/
c
        integer i,j,l,n,lup,llw,key
        double precision h0,fac,exponent,wave,dro
        double precision norm(2)
        double precision y0(4,2),c0(4,2),c1(4,2),b(4)
        double precision y1(4,2),yup(4,2),ylw(4,2)
        double precision ma(4,4),mai(4,4),hk(4,4)
        double precision orth(2,2),coef(4,4)
c
        do i=1,4
          y(i)=0.d0
        enddo
c
c===============================================================================
c
c       matrix propagation from surface to source
c
        do j=1,2
          do i=1,4
            c0(i,j)=0.d0
            yup(i,j)=0.d0
            y0(i,j)=0.d0
          enddo
        enddo
c
c       y0(4,2,1): 2 starting solution vectors
c
        lup=1
c
      exponent=0.d0
        do l=ls-1,1,-1
          n=nno(l)
        exponent=exponent-k*hp(l)
          if(exponent.le.dlog(eps))then
            lup=l+1
            if(lup.gt.lzrec)return
            goto 100
          endif
        enddo
100     continue
c
c       determination of starting sublayer for half-space
c
        llw=lp
      exponent=0.d0
        do l=ls,lp-1
          n=nno(l)
        exponent=exponent-k*hp(l)
          if(exponent.le.dlog(eps))then
            llw=l
            if(llw.lt.lzrec)return
            goto 200
          endif
        enddo
200     continue
c
        if(lup.eq.1)then
          yup(1,1)=1.d0
        dro=ro(1)
        yup(2,1)=dro*gravity*yup(1,1)
          yup(3,2)=1.d0
        else
          c0(1,1)=1.d0
          c0(3,2)=1.d0
        n=nno(lup-1)
          call edgmatrix(ma,4,k,0.d0,n)
          call axb(ma,c0,4,4,2,yup)
        dro=ro(nno(lup))-ro(nno(lup-1))
        do j=1,2
          yup(2,j)=yup(2,j)+dro*gravity*yup(1,j)
        enddo
        endif
        if(lup.eq.lzrec)call memcpy(yup,y0,8)
c
        do l=lup+1,ls
          h0=hp(l-1)
        n=nno(l-1)
        if(k*h0.le.eps0)then
          call edghask(hk,4,k,h0,n)
          call axb(hk,yup,4,4,2,y1)
          call memcpy(y1,yup,8)    
        else
c
c
c           determination of propagation matrix
c
            call edgmatinv(mai,4,k,0.d0,n)
            call edgmatrix(ma,4,k,h0,n)
            call axb(mai,yup,4,4,2,c0)
          wave=dexp(-k*h0)
c
c           normalization of all modes
c
          do j=1,2
              norm(j)=0.d0
              do i=1,4
                norm(j)=norm(j)+c0(i,j)*c0(i,j)
              enddo
          enddo
          fac=1.d0/dsqrt(norm(1)*norm(2))
c
c           orthogonalization of the p-sv modes
c
            orth(1,1)=c0(3,2)*fac
            orth(1,2)=-c0(1,2)*fac
            orth(2,1)=-c0(3,1)*fac
            orth(2,2)=c0(1,1)*fac
            call axb(c0,orth,4,2,2,c1)
            if(l.gt.lzrec)then
            do j=1,2
              do i=1,2
                orth(i,j)=orth(i,j)*wave
              enddo
            enddo
              call axb(y0,orth,4,2,2,y1)
              call memcpy(y1,y0,8)
            endif
c
c           c1(1,1)=c1(1,1)
            c1(2,1)=c1(2,1)*wave*wave
            c1(3,1)=(0.d0,0.d0)
            c1(4,1)=c1(4,1)*wave*wave
c
            c1(1,2)=(0.d0,0.d0)
            c1(2,2)=c1(2,2)*wave*wave
c           c1(3,2)=c1(3,2)
            c1(4,2)=c1(4,2)*wave*wave
c
            call axb(ma,c1,4,4,2,yup)
        endif
        dro=ro(nno(l))-ro(nno(l-1))
        do j=1,2
          yup(2,j)=yup(2,j)+dro*gravity*yup(1,j)
        enddo
          if(l.eq.lzrec)call memcpy(yup,y0,8)
        enddo
c
c===============================================================================
c
c       matrix propagation from half-space to source
c
        do i=1,4
          do j=1,2
            c0(i,j)=0.d0
            ylw(i,j)=0.d0
          enddo
        enddo
c
c
c       c0(4,2): 2 coefficient vectors in the half-space
c
      n=nno(llw)
        if(vs(n).lt.eps0*vp(n))then
c
c         the lowest layer is fluid
c
        ylw(1,1)=1.d0
          ylw(3,2)=1.d0
        else
c
c         the lowest layer is solid
c
          c0(2,1)=1.d0
          c0(4,2)=1.d0
          call edgmatrix(ma,4,k,0.d0,n)
          call axb(ma,c0,4,4,2,ylw)
        endif
        if(llw.gt.ls.and.llw.eq.lzrec)call memcpy(ylw,y0,8)
c
        do l=llw-1,ls,-1
          h0=hp(l)
          n=nno(l)
        dro=ro(nno(l+1))-ro(nno(l))
        do j=1,2
          ylw(2,j)=ylw(2,j)-dro*gravity*ylw(1,j)
        enddo
        if(k*h0.le.eps0)then
          call edghask(hk,4,k,-h0,n)
          call axb(hk,ylw,4,4,2,y1)
          call memcpy(y1,ylw,8)
        else
c
c
c           determination of propagation matrix
c
            call edgmatinv(mai,4,k,0.d0,n)
            call edgmatrix(ma,4,k,-h0,n)
            call axb(mai,ylw,4,4,2,c0)
          wave=dexp(-k*h0)
c
c           normalization of all modes
c
          do j=1,2
              norm(j)=0.d0
              do i=1,4
                norm(j)=norm(j)+c0(i,j)*c0(i,j)
              enddo
          enddo
          fac=1.d0/dsqrt(norm(1)*norm(2))
c
c           orthogonalization of the p-sv modes
c
            orth(1,1)=c0(4,2)*fac
            orth(1,2)=-c0(2,2)*fac
            orth(2,1)=-c0(4,1)*fac
            orth(2,2)=c0(2,1)*fac
            call axb(c0,orth,4,2,2,c1)
            if(l.lt.lzrec)then
            do j=1,2
              do i=1,2
                orth(i,j)=orth(i,j)*wave
              enddo
            enddo
              call axb(y0,orth,4,2,2,y1)
              call memcpy(y1,y0,8)
            endif
c
          c1(1,1)=c1(1,1)*wave*wave
c          c1(2,1)=c1(2,1)
          c1(3,1)=c1(3,1)*wave*wave
            c1(4,1)=(0.d0,0.d0)
c
            c1(1,2)=c1(1,2)*wave*wave
            c1(2,2)=(0.d0,0.d0)
            c1(3,2)=c1(3,2)*wave*wave
c           c1(4,2)=c1(4,2)
c
            call axb(ma,c1,4,4,2,ylw)
        endif
          if(l.gt.ls.and.l.eq.lzrec)call memcpy(ylw,y0,8)
        enddo
c
c===============================================================================
c
c       conditions on the source surface
c
c
c       source function
c
        do i=1,4
          if(kpower(i).eq.1)then
            fac=k
          else
            fac=1.d0
          endif
          b(i)=sfct(i)*fac
          do j=1,2
            coef(i,j)=yup(i,j)
            coef(i,j+2)=-ylw(i,j)
          enddo
        enddo
        key=0
      call gemp(coef,b,4,1,1.d-99,key)
        if(key.eq.0)then
          print *,'warning in edgpsv: anormal exit from cgemp!'
          return
        endif
        if(lzrec.le.ls)then
          do i=1,4
            y(i)=0.d0
            do j=1,2
              y(i)=y(i)+b(j)*y0(i,j)
            enddo
          enddo
        else
          do i=1,4
            y(i)=0.d0
            do j=1,2
              y(i)=y(i)+b(j+2)*y0(i,j)
            enddo
          enddo
        endif
c
        return
        end
***********************************************************************
        subroutine edgsh(y,k,eps)
      implicit real*8 (a-h,o-z)
*        implicit none
c
c      First implemented in Potsdam, Feb, 1999
c      Last modified: Potsdam, Nov, 2001, by R. Wang
c
c      calculation of response to sh source
c       y(6): solution vector
c       k: wave number
c       eps: relative accuracy
c
        double precision k,eps
        double precision y(6)
c
*      include 'edgglobal.h'
      include 'edc.h'
cc
        integer lp,nno(nzmax)
        double precision hp(nzmax)
        common /sublayer/ hp,lp,nno
c
c       zrec: receiver depth
c       lzrec: sublayer no of receiver
c
        integer lzrec
        double precision zrec
        common /rec1/ zrec
        common /rec2/ lzrec
c       
c       model parameter:
c       nlayers: number of model layers
c
        integer nlayers
      dimension h(MAX_layers), vp(MAX_layers), vs(MAX_layers),
     .          ro(MAX_layers), player(7)
      common /model/ h,ro,vp,vs,player,nlayers 
c
c       source parameters
c
        integer ls,ms,ics
        integer kpower(6)
        double precision zs,r0
        double precision sfct(6)
        common /source/ zs,r0,sfct,ls,ms,ics,kpower
c
c       work space
c
        double precision eps0
        data eps0/1.0d-03/
c
        integer i,l,n,lup,llw,key
        double precision fac,exponent
        double precision y0(2),c0(2),b(2)
        double precision y1(2),yup(2),ylw(2)
        double precision hk(2,2),coef(2,2)
c
        do i=5,6
          y(i)=0.d0
        enddo
c
c===============================================================================
c
c       matrix propagation from surface to source
c
        do i=1,2
          c0(i)=0.d0
          y0(i)=0.d0
        y1(i)=0.d0
          yup(i)=0.d0
        enddo
c
c       yup: the starting solution vector
c
        lup=1
c
      exponent=0.d0
        do l=ls-1,1,-1
          n=nno(l)
        exponent=exponent-k*hp(l)
          if(exponent.le.dlog(eps))then
            lup=l+1
            if(lup.gt.lzrec)return
            goto 100
          endif
        enddo
100     continue
c
c       determination of starting sublayer for half-space
c
      exponent=0.d0
        llw=lp
        do l=ls,lp-1
          n=nno(l)
        exponent=exponent-k*hp(l)
          if(exponent.le.dlog(eps))then
            llw=l
            goto 200
          endif
        enddo
200     continue
c
        yup(1)=1.d0
        if(lup.gt.1)then
          n=nno(lup-1)
        yup(2)=ro(n)*vs(n)**2*k
        endif
        if(lup.eq.lzrec)call memcpy(yup,y0,2)
c
        do l=lup+1,ls
          n=nno(l-1)
c
c         determination of propagation matrix
c
        call edghask(hk,2,k,hp(l-1),n)
        call axb(hk,yup,2,2,1,y1)
        fac=dexp(-k*hp(l-1))
        do i=1,2
          yup(i)=y1(i)*fac
        enddo
c
        if(l.gt.lzrec)then
          do i=1,2
            y0(i)=y0(i)*fac
          enddo
        else if(l.eq.lzrec)then
          call memcpy(yup,y0,2)
        endif
        enddo
c
c===============================================================================
c
c       matrix propagation from half-space to source
c
        do i=1,2
          c0(i)=0.d0
          y1(i)=0.d0
          ylw(i)=0.d0
        enddo
c
c       ylw: the starting solution vector
c
        n=nno(llw)
        ylw(1)=1.d0
        if(vs(n).lt.eps0*vp(n))then
c
c         the lowest layer is fluid
c
        ylw(2)=0.d0
        else
c
c         the lowest layer is solid
c
          ylw(2)=-ro(n)*vs(n)**2*k
        endif
        if(llw.gt.ls.and.llw.eq.lzrec)call memcpy(ylw,y0,2)
c
        do l=llw-1,ls,-1
          n=nno(l)
c
c         determination of propagation matrix
c
        call edghask(hk,2,k,-hp(l),n)
        call axb(hk,ylw,2,2,1,y1)
        fac=dexp(-k*hp(l))
        do i=1,2
          ylw(i)=y1(i)*fac
        enddo
c
        if(l.lt.lzrec)then
          do i=1,2
            y0(i)=y0(i)*fac
          enddo
        else if(l.gt.ls.and.l.eq.lzrec)then
          call memcpy(ylw,y0,2)
        endif
        enddo
c
c===============================================================================
c
c       conditions on the source surface
c
c
c       source function
c
        do i=1,2
          if(kpower(i+4).eq.1)then
            fac=k
          else
            fac=1.d0
          endif
          b(i)=sfct(i+4)*fac
          coef(i,1)=yup(i)
          coef(i,2)=-ylw(i)
        enddo
        key=0
        call gemp(coef,b,2,1,1.d-99,key)
        if(key.eq.0)then
          print *,'warning in edgsh: anormal exit from cgemp!'
          return
        endif
        if(lzrec.le.ls)then
          do i=1,2
            y(i+4)=b(1)*y0(i)
          enddo
        else
          do i=1,2
            y(i+4)=b(2)*y0(i)
          enddo
        endif
        return
        end
***********************************************************************

        subroutine edgwvint(u,r,nr,srate,itty)
      implicit real*8 (a-h,o-z)
*        implicit none
c
c      First implemented in Potsdam, Feb, 1999
c      Last modified: Potsdam, Nov, 2001, by R. Wang
c
        integer nr,itty
*        double precision srate,lambda,mu
c
*      include 'edgglobal.h'
      include "defconst.h"
      include 'edc.h'

      logical disp_only
cc
        double precision r(nrmax)
        double precision u(10,nrmax)
c
c       table of J_n(x), dJ_n(x)/dx and n*J_n(x)/x
c      all multiplied by sqrt(x)
c
      double precision bsdx,bsfct(0:nnbess1,3)
      common /bessels/ bsdx,bsfct
c
        double precision eps,eps0
        data eps,eps0/1.0d-08,1.0d-03/
      double precision pi,pi2
      data pi,pi2/3.14159265358979d0,6.28318530717959d0/
c
        integer lp,nno(nzmax)
        double precision hp(nzmax)
        common /sublayer/ hp,lp,nno
c
c       zrec: receiver depth
c       lzrec: sublayer no of receiver
c
        integer lzrec
        double precision zrec
        common /rec1/ zrec
        common /rec2/ lzrec
c       
c       model parameter:
c       nlayers: number of model layers
c
        integer nlayers
      dimension h(MAX_layers), vp(MAX_layers), vs(MAX_layers),
     .          ro(MAX_layers), player(7)
      common /model/ h,ro,vp,vs,player,nlayers 
c
c       source parameters
c
        integer ls,ms,ics
        integer kpower(6)
        double precision zs,r0
        double precision sfct(6)
        common /source/ zs,r0,sfct,ls,ms,ics,kpower
c
c       parameters for hankel integrations
c
        integer i,ir,ir1,ncall,ik,nk,nx
        double precision k,k0,klimit,dk,x,wl,wr
        double precision cs,fps,fsh,fac,yabs,dyabs,ymax
        double precision y(6),y0(6),u0(6),uk0(6),bs(3),bs1(3)
      double precision r00(nrmax)
        logical ps,sh,analytic
c
c      ics = 1  when the azmuth-factor is cos(ms*theta) for poloidal mode
c               (psv) and sin(ms*theta) for the toroidal mode (sh);
c      ics = -1 otherwise.
c
        cs=dble(ics)
      fps=0.d0
      do i=1,4
        fps=fps+dabs(sfct(i))
      enddo
      if(fps.gt.0.d0)then
        ps=.true.
      else
        ps=.false.
      endif
      fsh=0.d0
      do i=5,6
        fsh=fsh+dabs(sfct(i))
      enddo
      if(fsh.gt.0.d0)then
        sh=.true.
      else
        sh=.false.
      endif
c
c      u: 1=uz, 2=ur, 3=ut, 4=ezz, 5=err, 6=ett, 7=ezr, 8=ert, 9=etz
c        10=duz/dr
c      NOTE: uz, ur, ezz, err, ett, ezr duz/dr have the same azimuth-factor
c            as the poloidal mode (p-sv);
c            ut, ert and etz have the same azimuth-factor as the
c            toroidal mode (sh);
c

****************************
**  for displacement calculations only
      disp_only = .true.
      nu=10
      if (disp_only) nu=3
****************************

        do ir=1,nr
        r00(ir)=dmax1(r0,1.0d-02*dabs(zs-zrec),1.0d-02*r(ir))
          do i=1,nu
            u(i,ir)=0.d0
          enddo
        enddo
      do i=1,6
        u0(i)=0.d0
        uk0(i)=0.d0
      enddo
      do i=1,6
        y0(i)=0.d0
      enddo
c
c      determine wavenumber limit
c
c      determine limits of y(i), i=1,...,6
c
        ncall=0
      if(zs.eq.zrec)then
        k0=eps0*pi2/(r0+dabs(zs-zrec)+r(nr))
          ymax=0.d0
10        yabs=0.d0
          call edgkern(y,k0,ps,sh,eps)
          ncall=ncall+1
          do i=1,5,2
            yabs=yabs+y(i)*y(i)
          enddo
        yabs=k0*dsqrt(k0*yabs)*dexp(-(k0*r0)**2)
        ymax=dmax1(ymax,yabs)
          if(yabs.gt.eps0*ymax)then
            k0=1.25d0*k0
            goto 10
          endif
c
        analytic=.true.
c
        k=eps0*pi2/(r0+dabs(zs-zrec)+r(nr))
20        call edgkern(y,k,ps,sh,eps)
          ncall=ncall+1
        do i=2,6,2
          y(i)=y(i)/(k*mu)
        enddo
        yabs=0.d0
        dyabs=0.d0
        do i=1,6
          yabs=yabs+y(i)**2
          dyabs=dyabs+(y(i)-y0(i))**2
          y0(i)=y(i)
        enddo
        if(dyabs.gt.eps*yabs)then
          if(k.ge.k0)then
            analytic=.false.
            do i=1,6
              y0(i)=0.d0
            enddo
          else
            k=1.25d0*k
            goto 20
          endif
        endif
        do i=2,6,2
          y0(i)=y0(i)*mu
        enddo
      else
        analytic=.false.
      endif
c
      klimit=eps*pi2/(r0+dabs(zs-zrec)+r(nr))
        ymax=0.d0
30      yabs=0.d0
        call edgkern(y,klimit,ps,sh,eps)
        ncall=ncall+1
        do i=1,5,2
          yabs=yabs+(y(i)-y0(i))**2
        enddo
      yabs=klimit*dsqrt(klimit*yabs)*dexp(-(klimit*r00(1))**2)
      ymax=dmax1(ymax,yabs)
        if(yabs.gt.eps0*ymax)then
          klimit=1.2d0*klimit
          goto 30
        endif
c
c      determine wavenumber sampling rate
c
      dk=pi2/(srate*(r00(1)+r(nr))+dabs(zs-zrec))
      nk=500+idnint(klimit/dk)
      dk=klimit/dble(nk)
c
c      too small distances will be treated as r = 0!
c
      if(r(1).gt.0.d0)then
        ir1=1
      else
        ir1=2
      endif
c
        do ik=1,nk
          k=dble(ik)*dk
          call edgkern(y,k,ps,sh,eps)
        if(analytic)then
          do i=1,5,2
            y(i)=y(i)-y0(i)
          enddo
          do i=2,6,2
            y(i)=y(i)-y0(i)*k
          enddo
        else if(ir1.eq.2)then
c
c        for r=0
c
          fac=k*dexp(-(k*r00(1))**2)*dk
          do i=1,6
            u0(i)=u0(i)+y(i)*fac
            uk0(i)=uk0(i)+y(i)*k*fac
          enddo
        endif
          do ir=ir1,nr
          fac=dsqrt(k)*dk*dexp(-(k*r00(ir))**2)/dsqrt(r(ir))
          x=k*r(ir)
c
c          bessels functions from pre-calculated tables
c
          nx=idint(x/bsdx)
          wr=x/bsdx-dble(nx)
          wl=1.d0-wr
          if(nx.gt.nnbess)then
            nx=nnbess+mod(nx-nnbess,ndbess)
            do i=1,3
              bs(i)=fac*(wl*bsfct(nx,i)+wr*bsfct(nx+1,i))
            enddo
            bs(3)=bs(3)*(dble(nx)+wr)*bsdx/x
          else
            do i=1,3
              bs(i)=fac*(wl*bsfct(nx,i)+wr*bsfct(nx+1,i))
            enddo
          endif
c
c          u1-3 are displacement components:
c          u4 = normal stress: szz
c          u5 = surface strain: err+ett
c          u6 will be derived later
c          u7 = shear stress: szr
c          u8 = strain component: dut/dr - (dur/dt)/r + ut/r
c          u9 = shear stress: szt
c          u10 = tilt: duz/dr
c
          u(1,ir)=u(1,ir)+y(1)*bs(1)
          u(2,ir)=u(2,ir)+y(3)*bs(2)+cs*y(5)*bs(3)
          u(3,ir)=u(3,ir)-cs*y(3)*bs(3)-y(5)*bs(2)

         if ( .not. disp_only) then
          u(4,ir)=u(4,ir)+y(2)*bs(1)
          u(5,ir)=u(5,ir)-y(3)*k*bs(1)
          u(7,ir)=u(7,ir)+y(4)*bs(2)+cs*y(6)*bs(3)
          u(8,ir)=u(8,ir)+y(5)*k*bs(1)
          u(9,ir)=u(9,ir)-cs*y(4)*bs(3)-y(6)*bs(2)
          u(10,ir)=u(10,ir)+y(1)*k*bs(2)
         endif

        enddo
        enddo
c
c       end of total integral
c
        if(itty.eq.1)then
          write(*,'(a,i7,a,i7)')'   wavenumber samples: ',ncall+nk,
     &                          ', really used: ',nk
        endif
c
      if(ir1.eq.2.and..not.analytic)then
c
c        for very small r including r=0
c
        if(ms.eq.0)then
          u(1,1)=u0(1)
          u(4,1)=u0(2)
          u(5,1)=-0.5d0*uk0(3)
          u(6,1)=u(5,1)
        else if(ms.eq.1)then
          u(2,1)=0.5d0*(u0(3)+cs*u0(5))
          u(3,1)=-0.5d0*(cs*u0(3)+u0(5))
          u(7,1)=0.5d0*(u0(4)+cs*u0(6))
          u(9,1)=-0.5d0*(cs*u0(4)+u0(6))
          u(10,1)=0.5d0*uk0(1)
        else if(ms.eq.2)then
          u(5,1)=0.25d0*(uk0(3)+cs*uk0(5))
          u(6,1)=-u(5,1)
          u(8,1)=-0.25d0*(cs*uk0(3)+uk0(5))
        endif
      endif
      do ir=ir1,nr
        if(analytic)then
          if(ms.eq.0)then
            bs(1)=0.d0
            bs(2)=-1.d0/r(ir)**2
            bs(3)=0.d0
            bs1(1)=-1.d0/r(ir)**3
            bs1(2)=0.d0
            bs1(3)=0.d0
          else if(ms.eq.1)then
            bs(1)=1.d0/r(ir)**2
            bs(2)=-1.d0/r(ir)**2
            bs(3)=1.d0/r(ir)**2
            bs1(1)=0.d0
            bs1(2)=-2.d0/r(ir)**3
            bs1(3)=1.d0/r(ir)**3
          else if(ms.eq.2)then
            bs(1)=2.d0/r(ir)**2
            bs(2)=-1.d0/r(ir)**2
            bs(3)=2.d0/r(ir)**2
            bs1(1)=3.d0/r(ir)**3
            bs1(2)=-4.d0/r(ir)**3
            bs1(3)=4.d0/r(ir)**3
          endif
          u(1,ir)=u(1,ir)+y0(1)*bs(1)
          u(2,ir)=u(2,ir)+y0(3)*bs(2)+cs*y0(5)*bs(3)
          u(3,ir)=u(3,ir)-y0(5)*bs(2)-cs*y0(3)*bs(3)

         if ( .not. disp_only) then
          u(4,ir)=u(4,ir)+y0(2)*bs1(1)
          u(5,ir)=u(5,ir)-y0(3)*bs1(1)
          u(7,ir)=u(7,ir)+y0(4)*bs1(2)+cs*y0(6)*bs1(3)
          u(8,ir)=u(8,ir)+y0(5)*bs1(1)
          u(9,ir)=u(9,ir)-y0(6)*bs1(2)-cs*y0(4)*bs1(3)
          u(10,ir)=u(10,ir)+y0(1)*bs1(2)
         end if

        endif
c
c        u6 is ett = ur/r + (dut/dt)/r
c
        u(6,ir)=(u(2,ir)+cs*dble(ms)*u(3,ir))/r(ir)
c
c        u5 now is err = u5(before) - ett
c
        u(5,ir)=u(5,ir)-u(6,ir)
c
c        u8 now is ert = 0.5 * u8(before) + (dur/dt)/r - ut/r
c                      = 0.5 * (dut/dr + (dur/dt)/r - ut/r)
c
        u(8,ir)=0.5d0*u(8,ir)-(cs*dble(ms)*u(2,ir)+u(3,ir))/r(ir)
      enddo

      if ( .not. disp_only) then
       do ir=1,nr
        u(4,ir)=(u(4,ir)-xlambda*(u(5,ir)+u(6,ir)))/(xlambda+2.d0*xmu)
        u(7,ir)=u(7,ir)/(2.d0*xmu)
        u(9,ir)=u(9,ir)/(2.d0*xmu)
       enddo
      endif
c
        return
        end

*******************************************************************************
        subroutine gemp(a,b,n,n1,eps,key)
      implicit real*8 (a-h,o-z)
*        implicit none
c-------------------------------------------------------------------------------
c       subroutine gemp to solve linear equation system                        i
c       a: coefficient matrix(n,n);                                            i
c       b: right-hand matrix(n,n1) by input,                                   i
c          solution matrix(n,n1) by return;                                    i
c       eps: control constant;                                                 i
c       key: the main term of a column                                         i
c            smaller than eps, key=0: anormal return,                          i
c            else key=1: normal return.                                        i
c-------------------------------------------------------------------------------
        integer n,n1,key
        double precision eps
        double precision a(n,n),b(n,n1)
c
        integer i,j,k,l,m
        double precision p
        double precision q
c
        do m=1,n
          p=0.d0
          do i=m,n
            do j=1,n
              if(dabs(a(i,j)).le.p)goto 10
              p=dabs(a(i,j))
              k=i
              l=j
10          continue
            enddo
          enddo
          key=0
          if(p.le.eps)return
          do j=1,n
            q=a(k,j)
            a(k,j)=a(m,j)
            a(m,j)=q
          enddo
          do j=1,n1
            q=b(k,j)
            b(k,j)=b(m,j)
            b(m,j)=q
          enddo
          do i=1,n
            q=-a(i,l)/a(m,l)
            if(i.eq.m)goto 20
            do j=1,n
              a(i,j)=a(i,j)+a(m,j)*q
            enddo
            do j=1,n1
              b(i,j)=b(i,j)+b(m,j)*q
            enddo
20          continue
          enddo
          q=a(m,l)
          do j=1,n
            a(m,j)=a(m,j)/q
          enddo
          do j=1,n1
            b(m,j)=b(m,j)/q
          enddo
        enddo
        do j=1,n
          do i=1,n
            if(a(i,j).lt.0.5d0)goto 30
            do k=1,n
              q=a(i,k)
              a(i,k)=a(j,k)
              a(j,k)=q
            enddo
            do k=1,n1
              q=b(i,k)
              b(i,k)=b(j,k)
              b(j,k)=q
            enddo
30          continue
          enddo
        enddo
        key=1
        return
        end

***********************************************************************

      subroutine edcsub (nrec,ns,grndir)
*      implicit none
      implicit real*8 (a-h,o-z)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c      this program calculates convolution integral (summation)       c
c      of discrete sources to model the elastic deformations induced  c
c       by an eqrthquake.                                              c
c                                                                      c
c      The input data will be read from an input file                 c
c                                                                      c
c      First implemented in Potsdam, Feb, 1999                        c
c      Last modified: Potsdam, Nov, 2001, by R. Wang                  c
c                                                                      c
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
c      BEGIN DECLARATIONS
c      ==================
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
c      GLOBAL CONSTANTS
c      ================
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      include 'edc.h'
      include "defconst.h"

c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
c      RECTANGULAR SOURCE PLANES
c      =========================
c
c      (xs,ys,zs) = coordinates of the start point of strike
c      with x = north, y = east, z = downward.
c      all angles in degree.
c      MAX_rect = the max. number of source rectangles
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*      double precision dislocation(MAX_rect)
*      double precision xs(MAX_rect),ys(MAX_rect),zs(MAX_rect)
*      double precision length(MAX_rect),width(MAX_rect)
*      double precision strike(MAX_rect),dip(MAX_rect),rake(MAX_rect)
c
*      common/rectangles/dislocation,xs,ys,zs,length,width,
*     &                    strike,dip,rake

** source dislocation rectangles in single array, in order
** slip, X, Y, Z, length, width, strike, dip, rake
      real*8 drec(MAX_rect,9)
      common /rect1/ drec

c
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
c      OBSERVATION POSITIONS AND OBSERVABLES
c      =====================================
c
c      (xrec(i),yrec(i),zrec0)=coordinates of the observation positions
c      (Note that zrec0 is fixed)
c      disp = the 3 displcement vector components: ux,uy,uz
c      strain = the 6 strain tensor components: exx,eyy,ezz,exy,eyz,ezx
c      tilt = the two vertical tilt components: dux/dz, duy/dz
c      MAX_rec = the max. number of observation positions
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      double precision xrec(MAX_rec),yrec(MAX_rec)
      double precision zrec0
      double precision disp(MAX_rec,3),strain(MAX_rec,6)
      double precision tilt(MAX_rec,2)
c
      common /obsarray1/ xrec,yrec
      common /zrec/ zrec0
      common /obsarray3/ disp
      common /obsarray2/ strain,tilt
c
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
c      ELASTIC PARAMETERS AT OBSERVATION DEPTH
c      =======================================
c
c      lambda,mu = the two Lame constants in pascal
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*      double precision xlambda,xmu
c
c
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
c      WARNING STATISTICS
c      ==================
c
c      nwarn = total number of warnings
c
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      integer nwarn
c
      common/warnings/nwarn
c
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
c      MEMORIES FOR OUTPUTS
c      ====================
c
c      1 = two displacement components: ux,uy,uz
c      2 = 6 strain components: exx,eyy,ezz,exy,eyz,ezx
c      3 = 6 stress components: sxx,syy,szz,sxy,syz,szx
c      4 = two vertical tilt components: dux/dz,duy/dz
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      character*3 outdir
      integer iouts(NFIELDS)
c
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
c      LOCAL CONSTANTS
c      ==============
c      pi, parameter for transforming degree to radian
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*      double precision PI,PI2
      data PI,PI2/3.14159265358979d0,6.28318530717959d0/
*      double precision DEGTORAD
      data DEGTORAD/1.745329252E-02/
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
c      LOCAL WORK SPACES
c      =================
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      integer i,is,irec,ixyrec,ixrec,iyrec,nxrec,nyrec,imodel
      integer nrec,ns
      double precision xrec1,xrec2,yrec1,yrec2,dxrec,dyrec
      double precision cxyrec1,cxyrec2
      character*80 infile
      character*3 grndir
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
c      END DECLARATIONS
c      ================
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
c00000000000000000000000000000000000000000000000000000000000000000000000
c      BEGIN READ IN INPUT PARAMETERS
c      ==============================
c00000000000000000000000000000000000000000000000000000000000000000000000
c
      nwarn=0
      outdir = grndir

c00000000000000000000000000000000000000000000000000000000000000000000000
c      READ IN PARAMETERS FOR OBSERVATION ARRAY
c      ========================================
c00000000000000000000000000000000000000000000000000000000000000000000000

       ixyrec = 0
*      print *, '-------------------------------------'
*      do i=1,ns
*       write(*,'(a6,9e14.6)') 'Srce: ',(drec(i,j),j=1,9)
*      enddo


      if(ixyrec.eq.0)then
c
c        irregular observation positions
c
*      nrec = # points
*      xrec(), yrec() = x,y arrays of point positions

        if(nrec.gt.MAX_rec)then
          stop ' Error in input file: MAX_rec too small!'
        endif

      else if(ixyrec.eq.1)then
c
c        1D observation profile
c
*       nrec = # points
*       cxyrec1,cxyrec2 = start x,y
*       dxrec, dyrec = x,y spacing
*
          do irec=1,nrec
            xrec(irec) = cxyrec1 + dxrec*dble(irec-1)
            yrec(irec) = cxyrec2 + dyrec*dble(irec-1)
          enddo

      else if(ixyrec.eq.2) then
c
c        2D rectanglar observation array
c
*      nxrec = # in x direction
*      xrec1 = starting x
*      xrec2 = ending x
*      nyrec = # in y direction
*      yrec1 = starting y
*      yrec2 = ending y

        nrec=nxrec*nyrec
        if(nrec.gt.MAX_rec.or.nrec.lt.1)then
          stop ' Error in input file: wrong input for nrec!'
        endif
        irec=0
        if(nxrec.gt.1)then
          dxrec=(xrec2-xrec1)/dble(nxrec-1)
        else
          dxrec=0.d0
        endif
        if(nyrec.gt.1)then
          dyrec=(yrec2-yrec1)/dble(nyrec-1)
        else
          dyrec=0.d0
        endif
        do iyrec=1,nyrec
          do ixrec=1,nxrec
            irec=irec+1
            xrec(irec)=xrec1+dxrec*dble(ixrec-1)
            yrec(irec)=yrec1+dyrec*dble(iyrec-1)
          enddo
        enddo
      else
        stop' Error in input file: wrong input for ixyrec!'
      endif
c00000000000000000000000000000000000000000000000000000000000000000000000
c      READ IN OUTPUT PARAMETERS
c      =========================
c00000000000000000000000000000000000000000000000000000000000000000000000
*      call getdata(10,dataline)
*        read(dataline,*)outdir
*      call getdata(10,dataline)
*        read(dataline,*)(iouts(i),i=1,NFIELDS)

       iouts(1) = 1
       do i=2,4
        iouts(i) =0
       enddo

*      call getdata(10,dataline)
*        read(dataline,*)(outputs(i),i=1,NFIELDS)
c00000000000000000000000000000000000000000000000000000000000000000000000
c      READ IN PARAMETERS FOR RECTANGULAR SOURCES
c      ==========================================
c00000000000000000000000000000000000000000000000000000000000000000000000


** sources to process
**  ns = # of rectangles
*     dislocation() = slip amplitude (m)
*     xs(),ys(),zs() = upper left corner of rectangle
*     length(), width() = of fault in meters
*     strike(),dip(),rake() of fault

      if(ns.gt.MAX_rect)then
        stop ' Error in edcmain: to large no of source rectangles!'
      endif

      do is=1,ns
        if(drec(is,5).lt.0.d0.or.drec(is,6).lt.0.d0)then
          stop ' Error in input data: source length or width < 0!'
        endif
        if(drec(is,4).lt.0.d0)then
          stop ' Error in input data: source depth < 0!'
        endif
        if(drec(is,5).eq.0.d0.and.drec(is,6).eq.0.d0)then
          write(*,'(a,i2,a)')' the ',is,'. rectangle is a point.'
        else if(drec(is,5).gt.0.d0.and.drec(is,6).eq.0.d0)then
          write(*,'(a,i2,a)')' the ',is,
     &                         '. rectangle is a horizontal line.'
        else if(drec(is,5).eq.0.d0.and.drec(is,6).gt.0.d0)then
          write(*,'(a,i2,a)')' the ',is,
     &                         '. rectangle is a vertical line.'
        endif
      enddo
c00000000000000000000000000000000000000000000000000000000000000000000000
c      READ IN PARAMETERS FOR EARTH MODEL CHOICE
c      =========================================
c00000000000000000000000000000000000000000000000000000000000000000000000
      imodel = 1

c00000000000000000000000000000000000000000000000000000000000000000000000
c      END READ IN INPUT PARAMETERS
c      ============================
c00000000000000000000000000000000000000000000000000000000000000000000000
*     print *,'... input data successful ...'
c00000000000000000000000000000000000000000000000000000000000000000000000
c      BEGIN PROCESSING
c      ================
c00000000000000000000000000000000000000000000000000000000000000000000000
*      if(imodel.eq.1)then
*       print *,'... layered half-space model considered ...'
*       print *,'... use the Green function approach ...'
        call edcgrn(ns,nrec,grndir)
*      else
*        print *,'... homogeneous half-space model considered ...'
*        print *,'... use analytical solutions of Okada ...'
*        call okada(ns,MAX_rect,nrec,MAX_rec,xlambda,xmu,dislocation,
*     &               xs,ys,zs,length,width,strike,dip,rake,
*     &               xrec,yrec,zrec0,disp,strain,tilt)
*      endif
*      print *,'... outputs ...'
      call edcoutput(nrec,infile,outdir,iouts)
c00000000000000000000000000000000000000000000000000000000000000000000000
c      END OF STANDARD PROCESSING
c      ==========================
c00000000000000000000000000000000000000000000000000000000000000000000000
      if(nwarn.eq.0)then
*        print *,'#        Successful computations with EDCMP        #'
      else
        print *,'     Sorry, there have been',nwarn,' warnings.      '
        print *,'             Results may be inaccurate!             '
      endif
c
      return
      end

***********************************************************************
      subroutine edreadgf (grndir, redo)

      implicit real*8 (a-h,o-z)

      include 'edc.h'
      include "defconst.h"

      character*3 grndir
      character*180 dataline
      character*30 grnss, grnds, grncl, grnhd

      logical redo, fexist
c
c      READ IN GREEN'S FUNCTIONS
c      =========================
c
      dimension ssdisp(3,NRMAX+2,NZMAX+2), dsdisp(3,NRMAX+2,NZMAX+2),
     .          cldisp(2,NRMAX+2,NZMAX+2)
*!*      dimension ssstrn(6,NRMAX+2,NZMAX+2), dsstrn(6,NRMAX+2,NZMAX+2),
*!*     .          clstrn(4,NRMAX+2,NZMAX+2
*!*      dimension ssuzr(NRMAX+2,NZMAX+2), dsuzr(NRMAX+2,NZMAX+2),
*!*     .          cluzr(NRMAX+2,NZMAX+2)

      common /edgf1/ ssdisp, dsdisp, cldisp
*!*      common /edgf2/ ssstrn, dsstrn, clstrn
*!*      common /edgf3/ ssuzr,  dsuzr,  cluzr
      common /edgf4/ r1, r2, z1, z2
      common /edgf5/ nr, nz
      common /zrec/ zrec0

      integer nlayers
      dimension h(MAX_layers), vp(MAX_layers), vs(MAX_layers),
     .          ro(MAX_layers), player(7)
      common /model/ h,ro,vp,vs,player,nlayers 

       len=index(gfname,' ')-1
       grnhd = grndir//'/'//gfname(1:len)//'.hdr'
       grnss = grndir//'/'//gfname(1:len)//'.ss'
       grnds = grndir//'/'//gfname(1:len)//'.ds'
       grncl = grndir//'/'//gfname(1:len)//'.cl'

*      print *, grnss, grnds, grncl
c
c      READ GREEN'S FUNCTIONS
c      ======================
c
c      for point strike-slip source
c
c      ssdisp(1-3): Uz, Ur, Ut
c      ssstrn(1-6): Ezz,Err,Ett,Ezr=Erz,Ert=Etr,Etz=Ezt
c


******
**  read header file describing the layered structure and Green's functions
*** see if file exists
      redo = .false.
      inquire( file=grnhd, exist = fexist)
      if ( .not. fexist ) then
       print *, 'No GF header file'
       redo = .true.
       return
      endif

      kk=66
      open(kk, file = grnhd)
      read(kk, 1) nr,r1,r2,nz,z1,z2,zrec0,xlambda,xmu

      read(kk, '(i5)') nl
       if ( nl .ne. nlayers ) redo = .true.
       do i=1,nl
        read(kk, '(4e12.4)') h1,vp1,vs1,ro1
        if ( h1 .ne. h(i) .or. vp1 .ne. vp(i) .or.
     .     vs1 .ne. vs(i) .or. ro1 .ne. ro(i) ) redo = .true.
       enddo
       close(kk)

       if ( redo ) then
         print *, '**** Layering not as in GFs'
         return 
       endif


      print *, grnss,' Green fcts for the strike-slip source ...'

      open(kk,file=grnss,status='old')
      call getdata(kk,dataline)
        read(dataline,*)nr,r1,r2,nz,z1,z2,zrec0,xlambda,xmu

      if(nr.gt.NRMAX)then
        stop ' Error in edcgrn: too large no of Green fct distantces!'
      else if(nz.gt.NZMAX)then
        stop ' Error in edcgrn: too large no of Green fct depths!'
      endif
      read(kk,*)(((ssdisp(i,ir,iz),i=1,3),
     &            ir=1,nr),iz=1,nz)
*!*      read(kk,*)(((ssdisp(i,ir,iz),i=1,3),(ssstrn(i,ir,iz),i=1,6),
*!*     &            ssuzr(ir,iz),ir=1,nr),iz=1,nz)
      close(kk)
c
c      for point dip-slip source
c
c      dsdisp(1-3): Uz, Ur, Ut
c      dsstrn(1-6): Ezz,Err,Ett,Ezr=Erz,Ert=Etr,Etz=Ezt
c
      print *,grnds,' Green fcts for the dip-slip source ...'

      open(kk,file=grnds,status='old')
      call getdata(kk,dataline)
        read(dataline,*)nx,x1,x2,ny,y1,y2,zobs,xla1,xmu1

      if(nx.ne.nr.or.x1.ne.r1.or.x2.ne.r2.or.
     &     ny.ne.nz.or.y1.ne.z1.or.y2.ne.z2)then
        stop ' Error in edcgrn: different grids in Green functions!'
      endif
      if(xla1.ne.xlambda.or.xmu1.ne.xmu)then
        stop ' Error in edcgrn: different Lame const. in Green fcts!'
      endif
      if(zobs.ne.zrec0)then
        stop ' Error in edcgrn: different obs.depth in Green fcts!'
      endif
      read(kk,*)(((dsdisp(i,ir,iz),i=1,3),
     &            ir=1,nr),iz=1,nz)
*!*      read(kk,*)(((dsdisp(i,ir,iz),i=1,3),(dsstrn(i,ir,iz),i=1,6),
*!*     &            dsuzr(ir,iz),ir=1,nr),iz=1,nz)
      close(kk)
c
c      for point clvd source
c
c
c      cldisp(1-2): Uz, Ur (Ut=0)
c      clstrn(1-4): Ezz,Err,Ett,Ezr=Erz (Ert=Etr=Etz=Ezt=0)
c
      print *, grncl,' Green fcts for the clvd source ...'

      open(kk,file=grncl,status='old')
      call getdata(kk,dataline)
        read(dataline,*)nx,x1,x2,ny,y1,y2,zobs,xla1,xmu1

      if(nx.ne.nr.or.x1.ne.r1.or.x2.ne.r2.or.
     &     ny.ne.nz.or.y1.ne.z1.or.y2.ne.z2)then
        stop ' Error in edcgrn: different grids in Green functions!'
      endif
      if(xla1.ne.xlambda.or.xmu1.ne.xmu)then
        stop ' Error in edcgrn: different Lame const. in Green fcts!'
      endif
      if(zobs.ne.zrec0)then
        stop ' Error in edcgrn: different obs.depth in Green fcts!'
      endif
      read(kk,*)(((cldisp(i,ir,iz),i=1,2),
     &            ir=1,nr),iz=1,nz)
*!*      read(kk,*)(((cldisp(i,ir,iz),i=1,2),(clstrn(i,ir,iz),i=1,4),
*!*     &            cluzr(ir,iz),ir=1,nr),iz=1,nz)
      close(kk)
c
      do iz=nz+1,nz+2
        do ir=nr+1,nr+2
          do i=1,3
            ssdisp(i,ir,iz)=0.d0
            dsdisp(i,ir,iz)=0.d0
          enddo
          do i=1,2
            cldisp(i,ir,iz)=0.d0
          enddo
*!*          do i=1,6
*!*            ssstrn(i,ir,iz)=0.d0
*!*            dsstrn(i,ir,iz)=0.d0
*!*          enddo
*!*          do i=1,4
*!*            clstrn(i,ir,iz)=0.d0
*!*          enddo
*!*          ssuzr(ir,iz)=0.d0
*!*          dsuzr(ir,iz)=0.d0
*!*          cluzr(ir,iz)=0.d0
        enddo
      enddo
c
      print *,'... read in Green fcts successfully ...'

  1   format(2(i4,2E13.5),4E13.5)

      return
      end


***********************************************************************
      subroutine edcgrn(ns,nrec,grndir)
      implicit real*8 (a-h,o-z)
*      implicit none
c
c      First implemented in Potsdam, Feb, 1999
c      Last modified: Potsdam, Nov, 2001, by R. Wang
c
c
      include 'edc.h'
      include "defconst.h"
*      include 'edcglobal.h'
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
c      RECTANGULAR SOURCE PLANES
c      =========================
c
c      (xs,ys,zs) = coordinates of the start point of strike
c      with x = north, y = east, z = downward.
c      all angles in degree.
c      MAX_rect = the max. number of source rectangles
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
** source rectangles
** slip, X, Y, Z, length, width, strike, dip, rake
      real*8 drec(MAX_rect,9)
      common /rect1/ drec
c
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
c      OBSERVATION POSITIONS AND OBSERVABLES
c      =====================================
c
c      (xrec(i),yrec(i),zrec0)=coordinates of the observation positions
c      (Note that zrec0 is fixed)
c      disp = the 3 displcement vector components: ux,uy,uz
c      strain = the 6 strain tensor components: exx,eyy,ezz,exy,eyz,ezx
c      tilt = the two vertical tilt components: dux/dz, duy/dz
c      MAX_rec = the max. number of observation positions
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      dimension xrec(MAX_rec),yrec(MAX_rec)
      dimension disp(MAX_rec,3),strain(MAX_rec,6), tilt(MAX_rec,2)
c
      common /obsarray1/ xrec,yrec
      common /zrec/ zrec0
      common /obsarray2/ strain,tilt
      common /obsarray3/ disp
c
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
c      DISCRETE POINT SOURCES
c      ======================
c
c      (xs,ys,zs) = coordinates of the discrete point sources
c      with x = north, y = east, z = downward
c      angles in degree.
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      dimension pxs(NPSMAX),pys(NPSMAX),pzs(NPSMAX)
      dimension pmoment(5,NPSMAX)
c
      common/pointsources/pxs,pys,pzs,pmoment
c
c
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
c      WARNING STATISTICS
c      ==================
c
c      nwarn = total number of warnings
c
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      common/warnings/nwarn
c
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
c      LOCAL CONSTANTS
c      ==============
c      pi, parameter for transforming degree to radian
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      data PI,PI2/3.14159265358979d0,6.28318530717959d0/
      data DEGTORAD,ZSEPS/1.745329252d-02,1.0d-02/
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
c      GREEN'S FUNNCTIONN PARAMETERS
c      =============================
c
c      Green's function source types:
c        1 = strike-slip (m12=m21=1)
c        2 = dip-slip (m13=m31=1)
c        3 = compensated linear vector dipole (CLVD)
c            (m11=m22=-1/2, m33=1) (no tangential component)
c      Green's function coordinate system:
c        (z,r,t) = cylindrical with z being downward(!)
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

      dimension ssdisp(3,NRMAX+2,NZMAX+2), dsdisp(3,NRMAX+2,NZMAX+2),
     .          cldisp(2,NRMAX+2,NZMAX+2)
*!*      dimension ssstrn(6,NRMAX+2,NZMAX+2), dsstrn(6,NRMAX+2,NZMAX+2),
*!*     .          clstrn(4,NRMAX+2,NZMAX+2
*!*      dimension ssuzr(NRMAX+2,NZMAX+2), dsuzr(NRMAX+2,NZMAX+2),
*!*     .          cluzr(NRMAX+2,NZMAX+2)

      common /edgf1/ ssdisp, dsdisp, cldisp
*!*      common /edgf2/ ssstrn, dsstrn, clstrn
*!*      common /edgf3/ ssuzr,  dsuzr,  cluzr
      common /edgf4/ r1, r2, z1, z2
      common /edgf5/ nr, nz

c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
c      LOCAL WORK SPACES
c      =================
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      integer i,irec,ips,nps,iz,idis
      double precision ur,ut,uz
*!*      double precision err,ett,ezz,ert,etz,ezr
      double precision si,co,si2,co2,dis,ddis,azi
      double precision dr,dz,dzs,w00,w10,w01,w11
*!*      double precision uzr,uzt
      double precision uzx,uzy,ps,sh

      character*3 grndir

** flags for displacement, strain, tilt
      logical dd, ss, tt
      dd = .true.
      ss = .true.
      tt = .true.

c
c      INITIALIZATION
c      ==============
c
      do irec=1,nrec
        do i=1,3
          disp(irec,i)=0.d0
        enddo
*!*        do i=1,6
*!*          strain(irec,i)=0.d0
*!*        enddo
*!*        do i=1,2
*!*          tilt(irec,i)=0.d0
*!*        enddo
      enddo


*      call edreadgf(grndir)

c
c      DISCRETISATION OF RECTANGULAR PLANE SOURCES
c      ===========================================
c
*     print *,'... discretise the finite sources ...'
c
      dr=(r2-r1)/dble(nr-1)
      dz=(z2-z1)/dble(nz-1)
      if(zrec0.ge.z1.and.zrec0.le.z2.and.r1.eq.0.d0)then
        iz=idnint((zrec0-z1)/dz)+1
        dzs=(zrec0-(z1+dz*dble(iz-1)))/dz
        if(dabs(dzs).le.ZSEPS)then
          do i=1,3
            ssdisp(i,1,iz)=ssdisp(i,2,iz)
            dsdisp(i,1,iz)=dsdisp(i,2,iz)
          enddo
          do i=1,2
            cldisp(i,1,iz)=cldisp(i,2,iz)
          enddo
*!*          do i=1,6
*!*            ssstrn(i,1,iz)=ssstrn(i,2,iz)
*!*            dsstrn(i,1,iz)=dsstrn(i,2,iz)
*!*          enddo
*!*          do i=1,4
*!*            clstrn(i,1,iz)=clstrn(i,2,iz)
*!*          enddo
*!*          ssuzr(1,iz)=ssuzr(2,iz)
*!*          dsuzr(1,iz)=dsuzr(2,iz)
*!*          cluzr(1,iz)=cluzr(2,iz)
        endif
      endif
c
      call edcdisc(ns,dr,dz,nps)
c
c      SUPERPOSITION OF ALL DISCRETE POINT SOURCES
c      ===========================================
c
c      disp(1-3): Ux,Uy,Uz
c      strain(1-6): Exx,Eyy,Ezz,Exy=Eyx,Eyz=Ezy,Ezx=Exz
c
*     print *,'... superposition of all discrete point sources ...'
      do irec=1,nrec
        uzx=0.d0
        uzy=0.d0
        do ips=1,nps
          dis=dsqrt((xrec(irec)-pxs(ips))**2
     &               +(yrec(irec)-pys(ips))**2)
          if(dis.le.0.d0)then
            azi=0.d0
          else
            azi=datan2(yrec(irec)-pys(ips),
     &                   xrec(irec)-pxs(ips))
          endif
c
          if(dis.gt.r2)then
*            print *,' Warning: too large distances ignored!'
*            nwarn=nwarn+1
          else if(pzs(ips).lt.z1)then
            print *,pzs(ips),z1,' Warning: too shallow sources ignored!'
            nwarn=nwarn+1
          else if(pzs(ips).gt.z2)then
            print *,pzs(ips),z2,' Warning: too deep sources ignored!'
            nwarn=nwarn+1
          else
            iz=idint((pzs(ips)-z1)/dz)+1
            dzs=(pzs(ips)-(z1+dz*dble(iz-1)))/dz
            if(dis.le.r1)then
              idis=1
              ddis=0.d0
            else
              idis=idint((dis-r1)/dr)+1
              ddis=(dis-(r1+dr*dble(idis-1)))/dr
            endif
c
c            weighting factors for the interpolation
c
            w00=(1.d0-ddis)*(1.d0-dzs)
            w10=ddis*(1.d0-dzs)
            w01=(1.d0-ddis)*dzs
            w11=ddis*dzs
c
            co=dcos(azi)
            si=dsin(azi)
            co2=dcos(2.d0*azi)
            si2=dsin(2.d0*azi)
c
c            pmoment(1-5):
c              1 = weight for strike-slip: m12=m21=1;
c              poloidal*sin(2 * theta), toroidal*cos(2 * theta)
c
c              2 = weight for dip-slip: m13=m31=1
c              poloidal * cos(theta), toroidal * sin(theta)
c
c              3 = weight for clvd: m33=-m11=-m22=1
c              axisymmetric
c
c              4 = weight for 45 deg strike-slip: m11=-m22=1
c              greenfct4(theta) = green1(theta + 45 deg)
c
c              5 = weight for 45 deg dip-slip: m23=m32=1
c              greenfct5(theta) = green2(theta - 90 deg)
c
c            contributions from the strike-slip components
c
            ps=pmoment(1,ips)*si2+pmoment(4,ips)*co2
            sh=pmoment(1,ips)*co2-pmoment(4,ips)*si2

         if (dd) then
            uz=ps*(w00*ssdisp(1,idis,iz)+w10*ssdisp(1,idis+1,iz)
     &           +w01*ssdisp(1,idis,iz+1)+w11*ssdisp(1,idis+1,iz+1))
            ur=ps*(w00*ssdisp(2,idis,iz)+w10*ssdisp(2,idis+1,iz)
     &           +w01*ssdisp(2,idis,iz+1)+w11*ssdisp(2,idis+1,iz+1))
            ut=sh*(w00*ssdisp(3,idis,iz)+w10*ssdisp(3,idis+1,iz)
     &           +w01*ssdisp(3,idis,iz+1)+w11*ssdisp(3,idis+1,iz+1))
         endif
c
*!*         if(ss) then
*!*            ezz=ps*(w00*ssstrn(1,idis,iz)+w10*ssstrn(1,idis+1,iz)
*!*     &            +w01*ssstrn(1,idis,iz+1)+w11*ssstrn(1,idis+1,iz+1))
*!*            err=ps*(w00*ssstrn(2,idis,iz)+w10*ssstrn(2,idis+1,iz)
*!*     &            +w01*ssstrn(2,idis,iz+1)+w11*ssstrn(2,idis+1,iz+1))
*!*            ett=ps*(w00*ssstrn(3,idis,iz)+w10*ssstrn(3,idis+1,iz)
*!*     &            +w01*ssstrn(3,idis,iz+1)+w11*ssstrn(3,idis+1,iz+1))
*!*            ezr=ps*(w00*ssstrn(4,idis,iz)+w10*ssstrn(4,idis+1,iz)
*!*     &            +w01*ssstrn(4,idis,iz+1)+w11*ssstrn(4,idis+1,iz+1))
*!*            ert=sh*(w00*ssstrn(5,idis,iz)+w10*ssstrn(5,idis+1,iz)
*!*     &            +w01*ssstrn(5,idis,iz+1)+w11*ssstrn(5,idis+1,iz+1))
*!*            etz=sh*(w00*ssstrn(6,idis,iz)+w10*ssstrn(6,idis+1,iz)
*!*     &            +w01*ssstrn(6,idis,iz+1)+w11*ssstrn(6,idis+1,iz+1))
*!*         endif
c
*!*         if (tt) then
*!*            uzr=ps*(w00*ssuzr(idis,iz)+w10*ssuzr(idis+1,iz)
*!*     &           +w01*ssuzr(idis,iz+1)+w11*ssuzr(idis+1,iz+1))
*!*            uzt=sh*(w00*ssdisp(1,idis,iz)+w10*ssdisp(1,idis+1,iz)
*!*     &           +w01*ssdisp(1,idis,iz+1)+w11*ssdisp(1,idis+1,iz+1))
*!*     &           *2.d0/dis
*!*         endif
c
c            contributions from the dip-slip components
c
            ps=pmoment(2,ips)*co+pmoment(5,ips)*si
            sh=pmoment(2,ips)*si-pmoment(5,ips)*co

         if (dd) then
            uz=uz+ps*(w00*dsdisp(1,idis,iz)+w10*dsdisp(1,idis+1,iz)
     &           +w01*dsdisp(1,idis,iz+1)+w11*dsdisp(1,idis+1,iz+1))
            ur=ur+ps*(w00*dsdisp(2,idis,iz)+w10*dsdisp(2,idis+1,iz)
     &           +w01*dsdisp(2,idis,iz+1)+w11*dsdisp(2,idis+1,iz+1))
            ut=ut+sh*(w00*dsdisp(3,idis,iz)+w10*dsdisp(3,idis+1,iz)
     &           +w01*dsdisp(3,idis,iz+1)+w11*dsdisp(3,idis+1,iz+1))
         endif
c
*!*         if (ss) then
*!*            ezz=ezz+ps*(w00*dsstrn(1,idis,iz)+w10*dsstrn(1,idis+1,iz)
*!*     &            +w01*dsstrn(1,idis,iz+1)+w11*dsstrn(1,idis+1,iz+1))
*!*            err=err+ps*(w00*dsstrn(2,idis,iz)+w10*dsstrn(2,idis+1,iz)
*!*     &            +w01*dsstrn(2,idis,iz+1)+w11*dsstrn(2,idis+1,iz+1))
*!*            ett=ett+ps*(w00*dsstrn(3,idis,iz)+w10*dsstrn(3,idis+1,iz)
*!*     &            +w01*dsstrn(3,idis,iz+1)+w11*dsstrn(3,idis+1,iz+1))
*!*            ezr=ezr+ps*(w00*dsstrn(4,idis,iz)+w10*dsstrn(4,idis+1,iz)
*!*     &            +w01*dsstrn(4,idis,iz+1)+w11*dsstrn(4,idis+1,iz+1))
*!*            ert=ert+sh*(w00*dsstrn(5,idis,iz)+w10*dsstrn(5,idis+1,iz)
*!*     &            +w01*dsstrn(5,idis,iz+1)+w11*dsstrn(5,idis+1,iz+1))
*!*            etz=etz+sh*(w00*dsstrn(6,idis,iz)+w10*dsstrn(6,idis+1,iz)
*!*     &            +w01*dsstrn(6,idis,iz+1)+w11*dsstrn(6,idis+1,iz+1))
*!*         endif
c
*!*         if (tt) then
*!*            uzr=uzr+ps*(w00*dsuzr(idis,iz)+w10*dsuzr(idis+1,iz)
*!*     &         +w01*dsuzr(idis,iz+1)+w11*dsuzr(idis+1,iz+1))
*!*            uzt=uzt+sh*(w00*dsdisp(1,idis,iz)+w10*dsdisp(1,idis+1,iz)
*!*     &           +w01*dsdisp(1,idis,iz+1)+w11*dsdisp(1,idis+1,iz+1))
*!*     &           *(-1.d0/dis)
*!*         endif
c
c            contributions from the clvd components
c
            ps=pmoment(3,ips)

         if (dd) then
            uz=uz+ps*(w00*cldisp(1,idis,iz)+w10*cldisp(1,idis+1,iz)
     &           +w01*cldisp(1,idis,iz+1)+w11*cldisp(1,idis+1,iz+1))
            ur=ur+ps*(w00*cldisp(2,idis,iz)+w10*cldisp(2,idis+1,iz)
     &           +w01*cldisp(2,idis,iz+1)+w11*cldisp(2,idis+1,iz+1))
         endif
c
*!*         if (ss) then
*!*            ezz=ezz+ps*(w00*clstrn(1,idis,iz)+w10*clstrn(1,idis+1,iz)
*!*     &            +w01*clstrn(1,idis,iz+1)+w11*clstrn(1,idis+1,iz+1))
*!*            err=err+ps*(w00*clstrn(2,idis,iz)+w10*clstrn(2,idis+1,iz)
*!*     &            +w01*clstrn(2,idis,iz+1)+w11*clstrn(2,idis+1,iz+1))
*!*            ett=ett+ps*(w00*clstrn(3,idis,iz)+w10*clstrn(3,idis+1,iz)
*!*     &            +w01*clstrn(3,idis,iz+1)+w11*clstrn(3,idis+1,iz+1))
*!*            ezr=ezr+ps*(w00*clstrn(4,idis,iz)+w10*clstrn(4,idis+1,iz)
*!*     &            +w01*clstrn(4,idis,iz+1)+w11*clstrn(4,idis+1,iz+1))
*!*         endif
c
*!*         if (tt) then
*!*            uzr=uzr+ps*(w00*cluzr(idis,iz)+w10*cluzr(idis+1,iz)
*!*     &           +w01*cluzr(idis,iz+1)+w11*cluzr(idis+1,iz+1))
*!*         endif
c
c    transform to cartesian coordinates

            disp(irec,1)=disp(irec,1)+ur*co-ut*si
            disp(irec,2)=disp(irec,2)+ur*si+ut*co
            disp(irec,3)=disp(irec,3)+uz

*!*            strain(irec,1)=strain(irec,1)+err*co*co+ett*si*si-ert*si2
*!*            strain(irec,2)=strain(irec,2)+err*si*si+ett*co*co+ert*si2
*!*            strain(irec,3)=strain(irec,3)+ezz
*!*            strain(irec,4)=strain(irec,4)+0.5d0*(err-ett)*si2+ert*co2
*!*            strain(irec,5)=strain(irec,5)+ezr*si+etz*co
*!*            strain(irec,6)=strain(irec,6)+ezr*co-etz*si

*!*            uzx=uzx+uzr*co-uzt*si
*!*            uzy=uzy+uzr*si+uzt*co

          endif
        enddo
c
c        transform of hrizontal tilts to vertical tilts
c
*!*        tilt(irec,1)=2.d0*strain(irec,6)-uzx
*!*        tilt(irec,2)=2.d0*strain(irec,5)-uzy
      enddo
c
      return
      end

***********************************************************************

      subroutine edcoutput(nrec,infile,outdir,iouts)
      implicit real*8 (a-h,o-z)
*      implicit none
c
c      First implemented in Potsdam, Feb, 1999
c      Last modified: Potsdam, Nov, 2001, by R. Wang
c
      include 'edc.h'
      include 'defconst.h'

*      include 'edcglobal.h'
c
      integer nrec,iouts(NFIELDS)
      character*80 outdir*3,infile
      character*4 outputs(NFIELDS)
c
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
c      ELASTIC PARAMETERS AT OBSERVATION DEPTH
c      =======================================
c
c      xlambda,xmu = the two Lame constants in pascal
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
c      OBSERVATION POSITIONS AND OBSERVABLES
c      =====================================
c
c      (xrec(i),yrec(i),zrec0)=coordinates of the observation positions
c      (Note that zrec0 is fixed)
c      disp = the 3 displcement vector components: ux,uy,uz
c      strain = the 6 strain tensor components: exx,eyy,ezz,exy,eyz,ezx
c      tilt = the two vertical tilt components: dux/dz, duy/dz
c      MAX_rec = the max. number of observation positions
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      double precision xrec(MAX_rec),yrec(MAX_rec)
      double precision zrec0
      double precision disp(MAX_rec,3),strain(MAX_rec,6)
      double precision tilt(MAX_rec,2)
c
      common/obsarray1/xrec,yrec
      common /zrec/ zrec0
      common /obsarray3/ disp
      common/obsarray2/strain,tilt
c
      integer i,leninf,lendir,irec
      double precision dilatation
      double precision stress(6)
      character*100 title
      character*160 outfile

      data outputs /'out1', 'out2', 'out3', 'out4' /
c
*      lendir=index(outdir,' ')-1
c
*      if(lendir.lt.1)then
*        stop ' Error in edcmain: wrong for output directory!'
*      endif
c
      leninf=index(infile,' ')-1
c
c      DATA OUTPUT
c      ===========
c
      if(iouts(1).eq.1)then
*       print *,'... output 3 displacement components ...'
c
        outfile=outdir(1:lendir)//outputs(1)
        open(31,file=outfile,status='unknown')
        write(31,'(a)')'# Displacements calculated with edcmp'
        write(31,'(a)')'# The input data file is '//infile(1:leninf)
        title='#   X_m         Y_m         '
     &        //'Ux_m        Uy_m        Uz_m'
        write(31,'(a57)')title
        do irec=1,nrec
          write(31,1001)xrec(irec),yrec(irec),(disp(irec,i),i=1,3)
        enddo
        close(31)
      endif
c
      if(iouts(2).eq.1)then
        print *,'... output 6 strain components ...'
c
        outfile=outdir(1:lendir)//outputs(2)
        open(32,file=outfile,status='unknown')
        write(32,'(a)')'# Strains calculated with edcmp'
        write(32,'(a)')'# The input data file is '
     &                 //infile(1:leninf)
        title='#   X_m         Y_m         Exx         Eyy'
     &         //'         Ezz         Exy         Eyz         Ezx'
        write(32,'(a91)')title
        do irec=1,nrec
          write(32,1001)xrec(irec),yrec(irec),(strain(irec,i),i=1,6)
        enddo
        close(32)
      endif
c
      if(iouts(3).eq.1)then
        print *,'... output 6 stress components ...'
c
        outfile=outdir(1:lendir)//outputs(3)
        open(33,file=outfile,status='unknown')
        write(33,'(a)')'# Stresses calculated with edcmp'
        write(33,'(a)')'# The input data file is '//infile(1:leninf)
        title='#   X_m         Y_m         Sxx_Pa      Syy_Pa'
     &            //'      Szz_Pa      Sxy_Pa      Syz_Pa      Szx_Pa'
        write(33,'(a94)')title
        do irec=1,nrec
          dilatation=strain(irec,1)+strain(irec,2)+strain(irec,3)
          stress(1)=xlambda*dilatation+2.d0*xmu*strain(irec,1)
          stress(2)=xlambda*dilatation+2.d0*xmu*strain(irec,2)
          stress(3)=xlambda*dilatation+2.d0*xmu*strain(irec,3)
          stress(4)=2.d0*xmu*strain(irec,4)
          stress(5)=2.d0*xmu*strain(irec,5)
          stress(6)=2.d0*xmu*strain(irec,6)
          if(zrec0.eq.0.d0)then
            stress(3)=0.d0
            stress(5)=0.d0
            stress(6)=0.d0
          endif
          write(33,1001)xrec(irec),yrec(irec),(stress(i),i=1,6)
        enddo
        close(33)
      endif
c
      if(iouts(4).eq.1)then
        print *,'... output 2 tilt components ...'
c
        outfile=outdir(1:lendir)//outputs(4)
        open(34,file=outfile,status='unknown')
        write(34,'(a)')'# Vertical tilts calculated with edcmp'
        write(34,'(a)')'# The input data file is '//infile(1:leninf)
        title='#   X_m         Y_m         dUx/dz      dUy/dz'
        write(34,'(a46)')title
        do irec=1,nrec
          write(34,1001)xrec(irec),yrec(irec),(tilt(irec,i),i=1,2)
        enddo
        close(34)
      endif
1001      format(8E12.4)
      return
      end

***********************************************************************

      subroutine getdata(kunit,line)
      implicit none
c
c      First implemented in Potsdam, Feb, 1999
c      Last modified: Potsdam, Nov, 2001, by R. Wang
c
      character line*180,char*1
c
      integer i
c
c      this subroutine reads over all comment lines starting with "#".
c
      char='#'
100      continue
      if(char.eq.'#')then
        read(kunit,'(a)')line
        i=1
        char=line(1:1)
200        continue
        if(char.eq.' ')then
          i=i+1
          char=line(i:i)
          goto 200
        endif
        goto 100
      endif
c
      return
      end
***********************************************************************
      subroutine edcdisc(ns,dr,dz,nps)
*      implicit none
      implicit real*8 (a-h,o-z)
c
c      First implemented in Potsdam, Feb, 1999
c      Last modified: Potsdam, Nov, 2001, by R. Wang
c
      include 'edc.h'

      integer ns,nz,nps
      double precision z1,z2,dr,dz

      common /edgf4/ r1, r2, z1, z2
      common /edgf5/ nr, nz

      dimension h(MAX_layers), vp(MAX_layers), vs(MAX_layers),
     .          ro(MAX_layers), player(7)
      common /model/ h,ro,vp,vs,player,nlayers 
c
c      inputs:
c      ns = total number of source rectangles
c      nz,z1,z2 = number of depth samples, start and end depths used
c            in Green's functions
c      dlength, dwidth = grid size for discretisation
c
c      returned outputs:
c      nps = total number of discrete point sources
c      other outputs through common blocks
c
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
c      LOCAL CONSTANTS
c      ===============
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      double precision DEGTORAD
      data DEGTORAD/1.745329252E-02/
c
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
c      RECTANGULAR SOURCE PLANES
c      =========================
c
c      (xs,ys,zs) = coordinates of the start point of strike
c      with x = north, y = east, z = downward.
c      all angles in degree.
c      MAX_rect = the max. number of source rectangles
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
** source rectangles
** slip, X, Y, Z, length, width, strike, dip, rake
      real*8 drec(MAX_rect,9)
      common /rect1/ drec
c
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
c      DISTRETE POINT SOURCES
c      ======================
c
c      (xs,ys,zs) = coordinates of the discrete point sources
c      with x = north, y = east, z = downward
c      angles in degree.
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      double precision pxs(NPSMAX),pys(NPSMAX),pzs(NPSMAX)
      double precision pmoment(5,NPSMAX)
c
      common/pointsources/pxs,pys,pzs,pmoment
c
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
c      OBSERVATION POSITIONS AND OBSERVABLES
c      =====================================
c
c      (xrec(i),yrec(i),zrec0)=coordinates of the observation positions
c      (Note that zrec0 is fixed)
c      disp = the 3 displcement vector components: ux,uy,uz
c      strain = the 6 strain tensor components: exx,eyy,ezz,exy,eyz,ezx
c      MAX_rec = the max. number of observation positions
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      double precision xrec(MAX_rec),yrec(MAX_rec)
      double precision zrec0
      double precision disp(MAX_rec,3),strain(MAX_rec,6)
      double precision tilt(MAX_rec,2)
c
      common/obsarray1/xrec,yrec
      common /zrec/ zrec0
      common /obsarray3/ disp
      common/obsarray2/strain,tilt
c
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
c      WARNING STATISTICS
c      ==================
c
c      nwarn = total number of warnings
c
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      integer nwarn
c
      common/warnings/nwarn
c
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
c      LOCAL WORK SPACES
c      =================
c~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      integer is,ix,iy,nx,ny
      double precision x,y,dx,dy,st,di,ra,disarea
      double precision dlength,dwidth, xs,ys,zs,xl,xw
      double precision sm(3,3)
c
*     write(*,'(a)')' ... discretise rectangular plane sources:'
      dlength=dr
      nps=0

      z1 = player(5)*1.0d3
      z2 = player(6)*1.0d3

      do is=1,ns
c
        disarea=drec(is,1)
        xs=drec(is,2)
        ys=drec(is,3)
        zs=drec(is,4)
        xl=drec(is,5)
        xw=drec(is,6)
        st=drec(is,7)*DEGTORAD
        di=drec(is,8)*DEGTORAD
        ra=drec(is,9)*DEGTORAD
        write(*, '(9e10.4)')(drec(is,i),i=1,9)


          if(di.gt.0.d0)then
          dwidth=dmin1(dr,dz/dsin(di))
          else
            dwidth=dr
          endif
c
        sm(1,1)=-dsin(di)*dcos(ra)*dsin(2.d0*st)
     &            -dsin(2.d0*di)*dsin(ra)*(dsin(st))**2
        sm(2,2)= dsin(di)*dcos(ra)*sin(2.d0*st)
     &            -dsin(2.d0*di)*dsin(ra)*(dcos(st))**2
        sm(3,3)=-(sm(1,1)+sm(2,2))
        sm(1,2)= dsin(di)*dcos(ra)*dcos(2.d0*st)
     &            +0.5d0*dsin(2.d0*di)*dsin(ra)*dsin(2.d0*st)
        sm(2,1)=sm(1,2)
        sm(1,3)=-dcos(di)*dcos(ra)*dcos(st)
     &            -dcos(2.d0*di)*dsin(ra)*dsin(st)
        sm(3,1)=sm(1,3)
        sm(2,3)=-dcos(di)*dcos(ra)*dsin(st)
     &            +dcos(2.d0*di)*dsin(ra)*dcos(st)
        sm(3,2)=sm(2,3)
c
        nx=max0(1,idnint(xl/dlength))
        ny=max0(1,idnint(xw/dwidth))
        dx=xl/dble(nx)
        dy=xw/dble(ny)
c
c        if one of length and width = 0, then it is a line source
c        if both length and width = 0, then it is a point source
c
        if(dx.gt.0.d0)then
          disarea=disarea*dx
        endif
        if(dy.gt.0.d0)then
          disarea=disarea*dy
        endif
c
        do ix=1,nx
          x=dx*(dble(ix)-0.5d0)
          do iy=1,ny
            y=dy*(dble(iy)-0.5d0)
            nps=nps+1

            if(nps.gt.NPSMAX)then
              print *,' Warning: too large number for discrete ',
     &                  'point sources (i.e., NPSMAX too small)!'
              nwarn=nwarn+1
              nps=NPSMAX
              return
            endif

            pxs(nps)=xs+x*dcos(st)-y*dcos(di)*dsin(st)
            pys(nps)=ys+x*dsin(st)+y*dcos(di)*dcos(st)
            pzs(nps)=zs+y*dsin(di)


            print *, nps,pzs(nps), z1,z2,dz

            if(pzs(nps).lt.z1-dz)then
              print *, pzs(nps), z1-dz
              print *,' Warning: parts of source rectangles shallower'
              print *,'          than the Green function grids!'
              nwarn=nwarn+1
            endif

            if(pzs(nps).gt.z2+dz)then
              print *, pzs(nps), z2+dz
              print *,' Warning: parts of source rectangles deeper'
              print *,'          than the Green function grids!'
              nwarn=nwarn+1
            endif
c
c            1 = weight for strike-slip: m12=m21=1;
c            2 = weight for dip-slip: m13=m31=1
c            3 = weight for clvd: m33=-m11=-m22=1
c            4 = weight for 45 deg strike-slip: m11=-m22=1
c            5 = weight for 45 deg dip-slip: m23=m32=1
c
            pmoment(1,nps)=sm(1,2)*disarea
            pmoment(2,nps)=sm(1,3)*disarea
            pmoment(3,nps)=sm(3,3)*disarea
            pmoment(4,nps)=0.5d0*(sm(1,1)-sm(2,2))*disarea
            pmoment(5,nps)=sm(2,3)*disarea
          enddo
        enddo
*        write(*,'(a,i2,a,i6,a)')' the ',is,'. rectangle => ',
*     &                            nx*ny,' point sources.'
      enddo
*     write(*,*)'------------------------------------------------'
*     write(*,'(a,i7)')' the total number of point sources: ',nps
c
      return
      end



************************************************************************      
      subroutine wangfin (kkk, 
     .    strike, dip, rake, 
     .    Xf, Yf, flength, Zmin, Zmax, 
     .    Slip, Xpt, Ypt, U)
      
************************************************************************
*** set up and run finite source solution for Wang layered model
*
*                   N
*                  /
*                /| strike
*        Ref:-> @------------------------
*               |\        p .            \ W
*               :-\      i .              \ i
*               |  \    l .                \ d
*               :90 \  S .                  \ t
*               |-dip\  .                    \ h
*               :     \. | rake               \ 
*               Z      -------------------------
*                             L e n g t h
*
************************************************************************

      implicit real*8 (a-h,o-z)
      include "defcomm1.h"
      include "defconst.h"
      include "edc.h"

      dimension U(3)
      logical prdetails, redoGF


**********************
** for layered models
** structure
      dimension h(MAX_layers), vp(MAX_layers), vs(MAX_layers),
     .          ro(MAX_layers), player(7)
      common /model/ h,ro,vp,vs,player,nlayers 

** observation points
      dimension xrec(MAX_rec), yrec(MAX_rec), disp(MAX_rec,3)
      common /obsarray1/ xrec,yrec
      common /zrec/ zrec0
      common /obsarray3/ disp

** source rectangles
** slip, X, Y, Z, length, width, strike, dip, rake
      dimension drec(MAX_rect,9)
      common /rect1/ drec


*** EDGRN GFs ************************

      dimension ssdisp(3,NRMAX+2,NZMAX+2), dsdisp(3,NRMAX+2,NZMAX+2),
     .          cldisp(2,NRMAX+2,NZMAX+2)
*!*      dimension ssstrn(6,NRMAX+2,NZMAX+2), dsstrn(6,NRMAX+2,NZMAX+2),
*!*     .          clstrn(4,NRMAX+2,NZMAX+2
*!*      dimension ssuzr(NRMAX+2,NZMAX+2), dsuzr(NRMAX+2,NZMAX+2),
*!*     .          cluzr(NRMAX+2,NZMAX+2)

      common /edgf1/ ssdisp, dsdisp, cldisp
*!*      common /edgf2/ ssstrn, dsstrn, clstrn
*!*      common /edgf3/ ssuzr,  dsuzr,  cluzr
      common /edgf4/ r1, r2, z1, z2
      common /edgf5/ nr, nz

      data eps,f0,f1,thou / 7.0d-3, 0.d0, 1.d0, 1.0d3 /
      izero=0


*** make GFs for EDGRN layered model if required
      if ( kkk .lt. 0) then

*******************************************************************************
*	PARAMETERS FOR THE OBSERVATION PROFILE
*	======================================
* 1. the uniform depth of the observation points [m]

      zrec0 =  0.0d0

* 2. number of the equidistant radial distances (max. = nrmax in edgglobal.h),
*    the start and end of the distances [m]

      n101=101
      nr = max(n101, player(1))
      nr = min(nr, nrmax)
      r1 = max(0.0d0, player(2)*thou)
      r2 = max(100.0d3, player(3)*thou)

* 3. number of the equidistant source depths (max. = nzsmax in edgglobal.h),
*    the start and end of the source depths [m]
      n51=51
      nzs = max(n51, player(4))
      nzs = min(nzs, nzsmax)
      zs1 = max(0.0d0, player(5)*thou)
      zs2 = max(10.0d3, player(6)*thou)

*    If possible, please choose the observation depth either significantly
*    different from the source depths or identical with one of them.
*
*    The 2D distance and depth grids defined here should be necessarily large
*    and dense enough for the discretisation of the real source-observation
*    configuration to be considered later.
*
*    r1,r2 = minimum and maximum horizontal source-observation distances
*    z1,z2 = minimum and maximum source depths

*	WAVENUMBER INTEGRATION PARAMETERS
* 1. sampling rate for wavenumber integration (the ratio between the Nyquist
*    wavenumber and the really used wavenumber sample; the suggested value is
*    10-128: the larger this value is chosen, the more accurate are the results
*    but also the more computation time will be required)

      srate = max(10.0d0, player(7))

*******************************************************************************
       redoGF = .false.
       call edreadgf(gfdir, redoGF)

       if (redoGF) then
        print *, 'Calling edgsub '
        call edgsub(nr, r1, r2, nzs, zs1, zs2,srate, gfdir)
        call edreadgf(gfdir, redoGF)
       end if

       return
      endif

** or read them
      if ( kkk .eq. 0) then
       call edreadgf(gfdir, redoGF)
       return
      endif

** get displacements
      cd=dcos(dip*d2r)
      sd=dsin(dip*d2r)
      if (cd .lt. eps ) sd = f1

*--- downdip width of fault
      fwide = dabs ((zmax - zmin) / sd ) 

*-- strike
*      alph = (90.0d0 - strike)*d2r
*      alph = strike*d2r
      
*-- translate origin, all points are in lon,lat, use fault as origin
      call project( xpt, ypt, xf, yf, xp, yp, izero)

      if ( prdetails) then
       call delaz ( ypt, xpt, yf, xf, d, az)
       call distkm(xpt,ypt,xf,yf,del)
       write (*, '(a10,4f10.2)') 'XpYpDelAZ ', xp, yp, del,az
      endif
      
*'-- rotate to fault coordinate system
*      x =  xp * dCOS(alph) + yp * dSIN(alph)
*      y = -xp * dSIN(alph) + yp * dCOS(alph)
      
      call cleareal(U, 3)
      call swap(xp,yp)

      nrec = 1
      xrec(1) =  xp*thou
      yrec(1) =  yp*thou

* no  Slip   xs        ys       zs        length    width   strike   dip  rake
*   1  10.0  0.0       0.0      0.0d+00    1.0d+05   1.5d+04  0.0    12.0   90.0

** convert inputs to meters
      ns=1
      str=strike
*      str=0.0d0
      drec(1,1) = Slip/thou
      drec(1,2) = 0.0d0
      drec(1,3) = 0.0d0
      drec(1,4) = abs(Zmin*thou)
      drec(1,5) = flength*thou
      drec(1,6) = fwide * thou
      drec(1,7) = str
      drec(1,8) = dip
      drec(1,9) = rake

*     print *, 'Calling edcsub '
      call edcsub (nrec,ns,gfdir)

* back to mm, swap Ux, Uy
      ux =  disp(1,2)*thou
      uy =  disp(1,1)*thou
      uz = -disp(1,3)*thou

*-- rotate by -ALPH back to coordinate system
*       alphn=-alph
*       alphn = 0.0d0
*       U1 =  Ux * dcos(alphn) + Uy * dsin(alphn)
*       U2 = -Ux * dsin(alphn) + Uy * dcos(alphn)

       u(1) = ux
       u(2) = uy
       u(3) = uz

      return
      end 

************************************************************************


