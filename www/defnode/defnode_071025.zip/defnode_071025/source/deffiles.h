*************************************************************************************
*** Paths to external files  ********************************************************
***  this file has to obey Fortran syntax
*************************************************************************************
** path of Smithsonian volcanoes file, needed if +vtw flag is set
      volcfile = '/home/mccafr/work/dn/votw.gmt'

** paths of earthquake files projected onto profiles, needed if +eqk flag set
**  set num_quakefiles to number of files used, if more than MAX_qfiles reset dimension of
**  MAX_qfiles in defcomm1.h
** files should contain longitude, latitude, depth for each quake

      num_quakefiles = 2
      quakefile(1) = '/home/mccafr/work/dn/EHB/ehb.gmt'
      quakefile(2) = '/home/mccafr/work/dn/pgc_quakes'
      quakefile(3) = '/home/mccafr/work/dn/uw_quakes'
      quakefile(2) = '/home/mccafr/work/dn/fiordland_2003.quakes'

** paths for CRUST2 rigidity files
** these are used for moment calculations if +cr2 flag is set, otherwise not needed
** see  http://mahi.ucsd.edu/Gabi/rem.dir/crust/crust2.html

      CNkey  =  '/home/mccafr/work/CRUST2/CNtype2_key.txt'
      CNtype =  '/home/mccafr/work/CRUST2/CNtype2.txt'
      CNelev =  '/home/mccafr/work/CRUST2/CNelevatio2.txt'

*************************************************************************************

