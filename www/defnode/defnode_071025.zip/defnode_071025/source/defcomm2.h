**** defcomm2
*  commons for simulated annealing routines
*  dimensions set in defcomm1.include

      parameter ( alpha=3, sa_tolerance=1.0d-12)

      integer first_strain_parm, first_node_parm
      
      common /sa4/ kparm_type(MAX_p), node_index(MAX_p) 

      common /sa5/  g_gf(MAX_nodes, MAX_gps,  4), 
     .              u_gf(MAX_nodes, MAX_up,   2), 
     .              t_gf(MAX_nodes, MAX_tilt, 4),
     .              s_gf(MAX_nodes, MAX_ss,   9, 2, 2),
     .              x_gf(MAX_nodes, MAX_ll,   4)
   
      common /sa6/ parm(MAX_p), parm_best(MAX_p), parm_err(MAX_p),
     .             pentype(14)

      common /sa7/ nodes_free, first_node_parm, nparms, 
     .   npp(MAX_x, MAX_z, MAX_f), first_strain_parm

      common /sa8/ ndat_gf(5), num_gf_new

      common /sa9/ gf_new(MAX_gps,2)

********* END
   

