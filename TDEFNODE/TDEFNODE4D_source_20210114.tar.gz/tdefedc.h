************************************************************************
c      GLOBAL CONSTANTS
c      ================
c
c      MAX_rec = max. number of observation positions
c      NZMAX = max. number of the discrete source depths
c      NRMAX = max. number of the discrete radial diatances
c      MAX_rect = max. number of the source rectangles
c      NPSMAX = max. number of discrete point sources each depth
************************************************************************
c
c      First implemented in Potsdam, Feb, 1999
c      Last modified: Potsdam, Nov, 2001, by R. Wang
c
c      global parameters:
c        nzmax: max. interface index;
c        lmax: max. no of total homogeneous layers (lmax <= nzmax-2);
c        nrmax: max. no of traces;
c        nzsmax: max. no of source depth samples.
c
*      parameter(nzmax=1002,lmax=10,nrmax=1001,nzsmax=401)
c

      integer NZMAX,NRMAX,MAX_rect,NPSMAX,MAX_rec,NFIELDS
      integer MAX_layers, nzsmax 
      parameter(
     .  NZMAX=401,
     .  NRMAX=1000,
     .  MAX_rect=3, 
     .  NPSMAX=5000,
     .  MAX_rec=3,
     .  NFIELDS=4,
     .  MAX_layers = 100,
     .  NZSMAX = 401  )

c      index parameters for bessel function table
c
      integer nbess,ndbess
      parameter(nbess=2048,ndbess=128)
      integer nnbess,nnbess1
      parameter(nnbess=nbess*ndbess,nnbess1=nnbess+ndbess)
c
c      earth gravity in cm/s^2
c
      double precision gravity
c      data gravity /0.982d+03/
      data gravity /0.d0/

      character*8 gfname
      common /g/ gfname

************************************************************************

